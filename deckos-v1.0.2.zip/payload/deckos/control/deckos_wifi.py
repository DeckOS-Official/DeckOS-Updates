"""Wi-Fi adapter for NetworkManager. Passwords are supplied through a PTY prompt,
never as command-line arguments or log messages.
"""
import os
import pty
import re
import select
import subprocess
import time
import termios

NMCLI = "/usr/bin/nmcli"


def nm(args, timeout=15):
    p = subprocess.run(
        [NMCLI, "--mode", "multiline", "--escape", "no", *args],
        capture_output=True, text=True, timeout=timeout, check=False,
        env={**os.environ, "LC_ALL": "C"}
    )
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout or "nmcli failed").strip())
    return p.stdout


def records(output):
    result, current, start_key = [], {}, None
    for raw in output.splitlines():
        if not raw.strip() or ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        key, value = key.strip(), value.strip()
        if start_key is None:
            start_key = key
        elif key == start_key and current:
            result.append(current)
            current = {}
        current[key] = value
    if current:
        result.append(current)
    return result


def _is_wifi_connection_type(value):
    """Accept both nmcli device and connection-profile Wi-Fi type names."""
    return value in ("wifi", "802-11-wireless")


def _wifi_device():
    rows = records(nm(["-f", "DEVICE,TYPE,STATE", "device", "status"]))
    for row in rows:
        if row.get("TYPE") == "wifi" and row.get("DEVICE"):
            return row["DEVICE"]
    raise RuntimeError("No Wi-Fi interface found")


def _connect_with_prompt(ssid, password=""):
    """Connect through nmcli's interactive prompt without exposing the key in argv."""
    if not isinstance(ssid, str) or not ssid or len(ssid.encode("utf-8")) > SSID_MAX:
        raise ValueError("Invalid network name")
    if "\x00" in ssid or "\n" in ssid or "\r" in ssid:
        raise ValueError("Invalid network name")
    if not isinstance(password, str) or len(password) > 256 or "\x00" in password or "\n" in password or "\r" in password:
        raise ValueError("Invalid password")

    master, slave = pty.openpty()
    # Keep the PTY interactive but disable local echo so the password cannot
    # reappear in captured terminal output.
    attrs = termios.tcgetattr(slave)
    attrs[3] &= ~termios.ECHO
    termios.tcsetattr(slave, termios.TCSANOW, attrs)
    env = {**os.environ, "LC_ALL": "C", "TERM": "dumb"}
    proc = subprocess.Popen(
        [NMCLI, "--ask", "--wait", "35", "device", "wifi", "connect", ssid],
        stdin=slave, stdout=slave, stderr=slave, close_fds=True, env=env
    )
    os.close(slave)
    output = bytearray()
    sent_password = False
    deadline = time.monotonic() + 42
    try:
        while time.monotonic() < deadline:
            ready, _, _ = select.select([master], [], [], 0.25)
            if ready:
                try:
                    chunk = os.read(master, 4096)
                except OSError:
                    chunk = b""
                if chunk:
                    output.extend(chunk)
                    if len(output) > 12000:
                        del output[:-6000]
                    # nmcli's prompt may be split across PTY reads. Match the
                    # complete accumulated prompt, including PSK/passphrase variants.
                    prompt_text = output.decode("utf-8", "replace").lower()
                    prompt = re.search(r"(?:password|passphrase|psk)[^\r\n]{0,160}:", prompt_text)
                    if not sent_password and prompt:
                        os.write(master, password.encode("utf-8") + b"\n")
                        sent_password = True
            if proc.poll() is not None:
                break
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=3)
            raise RuntimeError("Connection timed out")

        text = output.decode("utf-8", "replace")
        text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text).replace("\r", "")
        # Never let a supplied password escape in a diagnostic.
        if password:
            text = text.replace(password, "[hidden]")
        low = text.lower()
        if proc.returncode == 0:
            return {"ok": True, "message": "Connected", "password_required": sent_password}
        if not sent_password and any(word in low for word in ("password", "passphrase", "psk", "secrets were required")):
            return {"ok": False, "error": "password_required", "detail": "This network needs a password."}
        if any(word in low for word in (
                "secrets were required, but not provided", "wrong password",
                "invalid password", "password is incorrect", "invalid psk",
                "failed to authenticate", "authentication failed")):
            return {"ok": False, "error": "authentication_failed", "detail": "Wrong password, or the network refused the connection."}
        return {"ok": False, "error": "connection_failed", "detail": "Could not connect. Check that the network is in range and try again."}
    finally:
        os.close(master)
        if proc.poll() is None:
            proc.kill()
            proc.wait()


SSID_MAX = 32


def dispatch(action, params=None):
    params = params or {}
    try:
        if action == "wifi_status":
            rows = records(nm(["-f", "WIFI,STATE", "general", "status"]))
            vals = rows[0] if rows else {}
            active = ""
            active_rows = records(nm(["-f", "NAME,TYPE", "connection", "show", "--active"]))
            for row in active_rows:
                if _is_wifi_connection_type(row.get("TYPE")):
                    active = row.get("NAME", "")
                    break
            return {"ok": True, "wifi": {"enabled": vals.get("WIFI", "unknown"),
                    "network_state": vals.get("STATE", "unknown"),
                    "active_connection": active}}

        if action == "wifi_scan":
            rows = records(nm(["-f", "IN-USE,SSID,BSSID,CHAN,FREQ,SIGNAL,SECURITY",
                               "device", "wifi", "list", "--rescan", "yes"]))
            networks = []
            for row in rows:
                signal = row.get("SIGNAL", "")
                networks.append({"active": row.get("IN-USE", "") == "*",
                    "ssid": row.get("SSID") or "(hidden network)",
                    "bssid": row.get("BSSID", ""), "channel": row.get("CHAN", ""),
                    "frequency": row.get("FREQ", ""),
                    "signal": int(signal) if signal.isdigit() else None,
                    "security": row.get("SECURITY", "")})
            networks.sort(key=lambda n: (not n["active"], -(n["signal"] or 0), n["ssid"]))
            return {"ok": True, "networks": networks}

        if action == "wifi_saved":
            rows = records(nm(["-f", "NAME,TYPE,AUTOCONNECT", "connection", "show"]))
            saved = [{"name": r.get("NAME", ""), "autoconnect": r.get("AUTOCONNECT", "")}
                     for r in rows if _is_wifi_connection_type(r.get("TYPE"))]
            return {"ok": True, "networks": saved}

        if action == "wifi_connect":
            ssid = params.get("ssid")
            password = params.get("password", "")
            return _connect_with_prompt(ssid, password)

        if action == "wifi_connect_saved":
            name = params.get("name")
            if not isinstance(name, str) or not name or len(name) > 128 or any(c in name for c in "\x00\r\n"):
                raise ValueError("Invalid saved network")
            # Profile name is not a secret; NetworkManager retrieves its stored key.
            nm(["--wait", "35", "connection", "up", "id", name], timeout=40)
            return {"ok": True, "message": "Connected"}

        if action == "wifi_disconnect":
            # Disconnect the Wi-Fi device itself. `connection down` can be
            # immediately undone by NetworkManager autoconnect, making the
            # button appear ineffective. `device disconnect` also suppresses
            # automatic reactivation until the next explicit connection.
            device = _wifi_device()
            nm(["device", "disconnect", device], timeout=25)
            time.sleep(0.5)
            active_rows = records(nm(["-f", "NAME,TYPE,DEVICE", "connection", "show", "--active"]))
            if any(_is_wifi_connection_type(r.get("TYPE")) and
                   (not r.get("DEVICE") or r.get("DEVICE") == device)
                   for r in active_rows):
                raise RuntimeError("The Wi-Fi connection is still active")
            return {"ok": True, "message": "Wi-Fi disconnected"}

        return {"ok": False, "error": "unknown_wifi_action"}
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
        return {"ok": False, "error": "networkmanager_error", "detail": str(exc)}
