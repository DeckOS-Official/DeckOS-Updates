#!/usr/bin/python3
"""DeckOS Wi-Fi — Settings > System > Wi-Fi (looks like a Mixxx Settings page)."""
import json
import socket
import sys
import threading
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from PyQt6.QtCore import QTimer, pyqtSignal
from PyQt6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel

import deckos_ui as ui

SOCKET = "/run/deckos-control/control.sock"
REFRESH_MS = 20000
HIDDEN = ("(hidden network)", "(réseau masqué)", "--")

ERRORS = {
    "password_required": "This network needs a password.",
    "authentication_failed": "Wrong password, or the network refused the connection.",
    "connection_failed": "Could not connect. Check that the network is in range and try again.",
    "networkmanager_error": "The network service reported an error.",
}


def request(action, **params):
    payload = {"action": action, **params}
    data = (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(45)
        sock.connect(SOCKET)
        sock.sendall(data)
        result = bytearray()
        while b"\n" not in result and len(result) < 65536:
            part = sock.recv(8192)
            if not part:
                break
            result.extend(part)
    return json.loads(bytes(result).split(b"\n", 1)[0].decode("utf-8"))


def band_of(frequency):
    try:
        mhz = int(str(frequency).split()[0])
    except (ValueError, IndexError):
        return ""
    if mhz < 3000:
        return "2.4 GHz"
    if mhz < 5925:
        return "5 GHz"
    return "6 GHz"


def merge_networks(networks):
    """One entry per SSID (2.4 / 5 GHz access points of the same network merged)."""
    merged = {}
    for n in networks:
        ssid = n.get("ssid") or ""
        if not ssid or ssid in HIDDEN:
            continue
        entry = merged.setdefault(ssid, {"ssid": ssid, "signal": 0, "active": False,
                                         "security": "", "bands": set(), "channel": ""})
        signal = n.get("signal") or 0
        if signal >= entry["signal"]:
            entry["signal"] = signal
            entry["channel"] = n.get("channel", "")
        entry["active"] = entry["active"] or bool(n.get("active"))
        entry["security"] = entry["security"] or n.get("security", "")
        band = band_of(n.get("frequency"))
        if band:
            entry["bands"].add(band)
    result = list(merged.values())
    result.sort(key=lambda e: (not e["active"], -e["signal"], e["ssid"].lower()))
    return result


def error_text(result):
    code = result.get("error")
    if code in ERRORS and code != "networkmanager_error":
        return ERRORS[code]
    return result.get("detail") or ERRORS.get(code, "Operation failed.")


class WifiWindow(ui.DeckOSWindow):
    data_ready = pyqtSignal(dict)
    operation_ready = pyqtSignal(str, dict)

    def __init__(self):
        super().__init__("Wi-Fi", "Wireless networks")
        self.busy = False
        self.operation_busy = False
        self.keyboard_layout = "QWERTY"

        # Current connection
        self.content.addWidget(ui.Band("Current connection"))
        self.current = ui.Row("Searching…")
        self.current.label.setObjectName("RowValue")
        self.current_bars = self.current.add(ui.SignalBars(0))
        self.refresh_button = self.current.add(ui.action_button("REFRESH", "Action", self.refresh))
        self.disconnect_button = self.current.add(ui.action_button("DISCONNECT", "Danger", self.disconnect_wifi))
        self.content.addWidget(self.current)
        self.content.addSpacing(ui.ROW_GAP)

        # Available networks
        self.available_band = ui.Band("Available networks")
        self.content.addWidget(self.available_band)
        self.networks = ui.RowList()
        self.content.addWidget(ui.scroll(self.networks), 1)
        self.content.addSpacing(ui.ROW_GAP)

        # Saved networks
        self.content.addWidget(ui.Band("Saved networks", "Reconnect without a password"))
        self.saved = QFrame()
        self.saved.setObjectName("Row")
        self.saved.setFixedHeight(ui.ROW_H)
        self.saved_layout = QHBoxLayout(self.saved)
        self.saved_layout.setContentsMargins(14, 0, 12, 0)
        self.saved_layout.setSpacing(10)
        self.content.addWidget(self.saved)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(REFRESH_MS)
        self.data_ready.connect(self.update_data)
        self.operation_ready.connect(self.operation_done)
        self.refresh()

    def can_leave(self):
        return not self.operation_busy

    # -- data -------------------------------------------------------------
    def refresh(self):
        if self.busy or self.operation_busy:
            return
        self.busy = True
        self.refresh_button.setEnabled(False)
        self.set_hint("Scanning…")
        threading.Thread(target=self.load_data, daemon=True).start()

    def load_data(self):
        result = {}
        for action in ("wifi_status", "wifi_saved", "wifi_scan"):
            try:
                result[action] = request(action)
            except Exception as exc:
                result[action] = {"ok": False, "error": "service", "detail": str(exc)}
        self.data_ready.emit(result)

    def update_data(self, data):
        self.busy = False
        self.refresh_button.setEnabled(not self.operation_busy)

        status = data.get("wifi_status", {})
        scan = data.get("wifi_scan", {})
        networks = merge_networks(scan.get("networks", [])) if scan.get("ok") else []
        active = next((n for n in networks if n["active"]), None)

        if status.get("ok"):
            wifi = status.get("wifi", {})
            name = wifi.get("active_connection") or ""
            state = wifi.get("network_state", "unknown")
            enabled = wifi.get("enabled", "unknown")
            if name:
                self.current.label.setText(name)
                parts = ["Connected"]
                if active:
                    parts.append(f"Signal {active['signal']}%")
                    parts.append(" / ".join(sorted(active["bands"])))
                self.current.set_sub("   ·   ".join(p for p in parts if p), "ok")
            else:
                self.current.label.setText("Not connected")
                self.current.set_sub("Wi-Fi is off" if enabled != "enabled" else "Choose a network below",
                                     "error" if state != "connected" else "")
            self.disconnect_button.setEnabled(bool(name) and not self.operation_busy)
        else:
            self.current.label.setText("Wi-Fi service unavailable")
            self.current.set_sub(status.get("detail", "No answer from the DeckOS control service."), "error")
            self.disconnect_button.setEnabled(False)
        self.current_bars.percent = active["signal"] if active else 0
        self.current_bars.update()

        self.networks.clear()
        if not scan.get("ok"):
            row = ui.Row("Unable to scan for networks", scan.get("detail", ""))
            self.networks.add(row)
        elif not networks:
            self.networks.add(ui.Row("No network found", "Move closer to the access point, then tap REFRESH."))
        for n in networks:
            details = [n["security"] or "Open"]
            if n["bands"]:
                details.append(" / ".join(sorted(n["bands"])))
            row = ui.Row(n["ssid"], "   ·   ".join(details))
            row.add(ui.SignalBars(n["signal"]))
            pct = QLabel(f"{n['signal']}%")
            pct.setObjectName("RowSub")
            pct.setFixedWidth(42)
            row.add(pct)
            if n["active"]:
                b = row.add(ui.action_button("CONNECTED", "Primary"))  # status, no action
            else:
                b = row.add(ui.action_button("CONNECT", "Action",
                                             lambda _=False, net=n: self.connect_network(net)))
                b.setEnabled(not self.operation_busy)
            b.setFixedWidth(140)
            self.networks.add(row)
        self.available_band.hint.setText(f"{len(networks)} found  ·  updated {datetime.now():%H:%M}")

        while self.saved_layout.count():
            item = self.saved_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        saved = data.get("wifi_saved", {})
        profiles = saved.get("networks", []) if saved.get("ok") else []
        if not profiles:
            empty = QLabel("No saved network")
            empty.setObjectName("RowSub")
            self.saved_layout.addWidget(empty)
        for profile in profiles[:6]:
            name = profile.get("name", "")
            self.saved_layout.addWidget(ui.action_button(name.upper(), "Action",
                                                         lambda _=False, n=name: self.connect_saved(n)))
        self.saved_layout.addStretch()
        if not self.operation_busy:
            self.set_hint("Wireless networks")

    # -- actions ----------------------------------------------------------
    def connect_network(self, network):
        ssid = network["ssid"]
        password = ""
        if network.get("security"):
            dialog = ui.PasswordDialog(self, ssid, self.keyboard_layout)
            password = dialog.run()
            self.keyboard_layout = dialog.layout_name
            if password is None:
                return
        self.run_operation("wifi_connect", f"Connecting to {ssid}…", ssid=ssid, password=password)

    def connect_saved(self, name):
        self.run_operation("wifi_connect_saved", f"Connecting to {name}…", name=name)

    def disconnect_wifi(self):
        if ui.ask(self, "Disconnect Wi-Fi",
                  "Disconnect from the current network?\n\nDeckOS will not reconnect automatically "
                  "until you choose a network again.",
                  [("CANCEL", "Action", False), ("DISCONNECT", "Danger", True)]):
            self.run_operation("wifi_disconnect", "Disconnecting…")

    def run_operation(self, action, message, **params):
        if self.operation_busy:
            return
        self.operation_busy = True
        self.timer.stop()
        self.refresh_button.setEnabled(False)
        self.disconnect_button.setEnabled(False)
        self.set_hint(message, "")

        def work():
            try:
                result = request(action, **params)
            except Exception as exc:
                result = {"ok": False, "error": "service", "detail": str(exc)}
            self.operation_ready.emit(action, result)

        threading.Thread(target=work, daemon=True).start()

    def operation_done(self, action, result):
        self.operation_busy = False
        self.timer.start(REFRESH_MS)
        if result.get("ok"):
            done = {"wifi_disconnect": "Wi-Fi disconnected"}.get(action, "Connected")
            self.set_hint(done, "ok")
        else:
            self.set_hint("Failed", "error")
            ui.inform(self, "Wi-Fi", error_text(result), "Action")
        QTimer.singleShot(1200, self.refresh)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("DeckOS Wi-Fi")
    ui.setup_app(app)
    window = WifiWindow()
    window.present()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
