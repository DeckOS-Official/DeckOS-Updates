#!/usr/bin/env python3
"""DeckOS update engine.

A package is a folder holding:
    manifest.json        {"version", "package", "sha256"}
    manifest.json.sig    SSH Ed25519 signature of manifest.json (namespace deckos-update)
    <package>.zip        payload/app/mixxx
                         payload/resources/skins/<skin>/...
                         payload/deckos/<path>     (control/, update-manager/, launch.sh)

Every file it replaces is backed up first; an interrupted or failed update is
rolled back (journal in backup-updates/.active-transaction.json).
"""

import argparse
import hashlib
import json
import os
import py_compile
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

DECKOS = Path("/home/deck/DeckOS")
APP = DECKOS / "app"
SKINS = DECKOS / "resources/skins"
BACKUPS = DECKOS / "backup-updates"
LOG = Path("/var/log/deckos-update.log")
JOURNAL = BACKUPS / ".active-transaction.json"
KEEP_BACKUPS = 2
INSTALLED_VERSION = DECKOS / "updates/installed_version.json"

SIGNERS = DECKOS / "control/deckos_update_signers"
SIG_NAMESPACE = "deckos-update"
SIG_IDENTITY = "deckos-update"
SIG_SUFFIX = ".sig"

# DeckOS files a package may replace (paths relative to /home/deck/DeckOS)
DECKOS_PREFIXES = ("control/", "update-manager/")
DECKOS_FILES = ("launch.sh",)
MAX_FILES = 10000
MAX_SIZE = 2 * 1024 * 1024 * 1024


def log(message):
    message = str(message)
    print(message, flush=True)
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} {message}\n")
    except OSError:
        pass


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    except Exception:
        os.unlink(temporary)
        raise


def fix_owner(path):
    """--recover runs through sudo: give restored files back to deck."""
    if os.geteuid() != 0:
        return
    try:
        st = DECKOS.stat()
        for p in [path, *(path.rglob("*") if path.is_dir() else [])]:
            os.lchown(p, st.st_uid, st.st_gid)
    except OSError:
        pass


# ----------------------------------------------------------------------------
# Signature
# ----------------------------------------------------------------------------
def verify_signature(manifest_bytes, signature_path):
    """Raise unless manifest_bytes carries a valid DeckOS signature."""
    if not SIGNERS.is_file():
        raise RuntimeError("Update signing key missing on this DeckOS")
    if not Path(signature_path).is_file():
        raise RuntimeError("Package is not signed (manifest.json.sig missing)")
    try:
        result = subprocess.run(
            ["ssh-keygen", "-Y", "verify", "-f", str(SIGNERS), "-I", SIG_IDENTITY,
             "-n", SIG_NAMESPACE, "-s", str(signature_path)],
            input=manifest_bytes, capture_output=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise RuntimeError(f"Signature check unavailable: {error}")
    if result.returncode != 0:
        raise RuntimeError("Invalid signature: this package was not published by DeckOS")


def locate_package(folder):
    folder = Path(folder).resolve()
    manifest_path = folder / "manifest.json"

    if not manifest_path.is_file():
        raise RuntimeError("manifest.json not found")

    manifest_bytes = manifest_path.read_bytes()
    verify_signature(manifest_bytes, folder / ("manifest.json" + SIG_SUFFIX))
    manifest = json.loads(manifest_bytes.decode("utf-8"))
    package_name = manifest.get("package")

    if not isinstance(package_name, str):
        raise RuntimeError("Package name missing")

    relative = PurePosixPath(package_name)

    if relative.is_absolute() or ".." in relative.parts:
        raise RuntimeError("Forbidden package path")

    package = (folder / Path(*relative.parts)).resolve()

    if folder not in package.parents:
        raise RuntimeError("Invalid path")

    if not package.is_file() or package.suffix.lower() != ".zip":
        raise RuntimeError("Archive not found")

    expected = str(manifest.get("sha256", "")).lower()

    if len(expected) != 64 or sha256(package) != expected:
        raise RuntimeError("SHA-256 mismatch")

    return manifest, package


# ----------------------------------------------------------------------------
# Archive inspection
# ----------------------------------------------------------------------------
def deckos_relative(name):
    """payload/deckos/<rel> -> <rel> if it is a path DeckOS updates may replace."""
    rel = name[len("payload/deckos/"):]
    path = PurePosixPath(rel)
    if not rel or path.is_absolute() or ".." in path.parts or any(p.startswith(".") for p in path.parts):
        raise RuntimeError(f"Forbidden DeckOS path: {name}")
    if rel in DECKOS_FILES or any(rel.startswith(p) and len(path.parts) >= 2 for p in DECKOS_PREFIXES):
        if "__pycache__" in path.parts:
            raise RuntimeError(f"Forbidden DeckOS path: {name}")
        return rel
    raise RuntimeError(f"DeckOS file not allowed: {rel}")


def inspect_archive(package):
    files = []
    seen = set()

    with zipfile.ZipFile(package) as archive:
        if len(archive.infolist()) > MAX_FILES:
            raise RuntimeError("Archive too large")
        total_size = 0
        for info in archive.infolist():
            name = info.filename
            path = PurePosixPath(name)
            if info.is_dir():
                continue
            if path.is_absolute() or ".." in path.parts:
                raise RuntimeError("Forbidden path in archive")
            if name in seen:
                raise RuntimeError("Duplicate file in archive")
            seen.add(name)
            mode = (info.external_attr >> 16) & 0xFFFF
            if (mode & 0o170000) not in (0, 0o100000):
                raise RuntimeError("Forbidden file type")
            if name == "payload/app/mixxx":
                pass
            elif name.startswith("payload/resources/skins/"):
                if len(path.parts) < 4:
                    raise RuntimeError("Invalid skin structure")
            elif name.startswith("payload/deckos/"):
                deckos_relative(name)
            else:
                raise RuntimeError(f"File not allowed: {name}")
            total_size += info.file_size
            if total_size > MAX_SIZE:
                raise RuntimeError("Archive too large")
            files.append(name)

    if not files:
        raise RuntimeError("Empty package")
    return files


def validate_mixxx(binary):
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise RuntimeError("Mixxx is not executable")
    result = subprocess.run(["ldd", str(binary)], capture_output=True, text=True, timeout=30)
    if "not found" in result.stdout + result.stderr:
        raise RuntimeError("Missing system dependency")


# ----------------------------------------------------------------------------
# Backups
# ----------------------------------------------------------------------------
def prune_backups():
    """Keep only the KEEP_BACKUPS most recent full backups (pre-v2 is kept)."""
    try:
        backups = sorted(
            p for p in BACKUPS.iterdir()
            if p.is_dir() and not p.is_symlink() and not p.name.startswith(".")
            and p.name != "pre-v2" and (p / "mixxx").is_file()
        )
        for old in backups[:-KEEP_BACKUPS]:
            shutil.rmtree(old, ignore_errors=True)
            log(f"Old backup removed: {old.name}")
    except OSError as error:
        log(f"Warning: old backups not cleaned ({error})")


def remove_path(path):
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)


def restore_transaction():
    if not JOURNAL.is_file():
        return False

    data = json.loads(JOURNAL.read_text(encoding="utf-8"))
    backup = Path(data["backup"])
    log("Rolling back the interrupted update")

    if data.get("app_replaced", data.get("app_existed")):
        temporary = APP / "mixxx.restore"
        shutil.copy2(backup / "mixxx", temporary)
        os.replace(temporary, APP / "mixxx")
        fix_owner(APP / "mixxx")

    for item in reversed(data.get("skins", [])):
        current = SKINS / item["name"]
        previous = backup / "skins" / item["name"]
        if current.exists() or current.is_symlink():
            remove_path(current)
        if item["existed"] and previous.exists():
            shutil.copytree(previous, current)
            fix_owner(current)

    for item in reversed(data.get("deckos", [])):
        current = DECKOS / item["path"]
        previous = backup / "deckos" / item["path"]
        if item["existed"] and previous.is_file():
            temporary = current.with_name(current.name + ".restore")
            shutil.copy2(previous, temporary)
            os.replace(temporary, current)
            fix_owner(current)
        elif not item["existed"] and current.is_file():
            current.unlink()

    JOURNAL.unlink()
    log("Rollback finished")
    return True


# ----------------------------------------------------------------------------
# Install
# ----------------------------------------------------------------------------
def install(folder):
    restore_transaction()

    manifest, package = locate_package(folder)
    version = str(manifest.get("version", "")).strip()
    if not version:
        raise RuntimeError("Version missing")

    log(f"DeckOS Update Manager — {version}")
    log("Signature verified (DeckOS)")

    files = inspect_archive(package)
    has_app = "payload/app/mixxx" in files
    skins = sorted({PurePosixPath(n).parts[3] for n in files if n.startswith("payload/resources/skins/")})
    deckos_files = sorted(deckos_relative(n) for n in files if n.startswith("payload/deckos/"))

    BACKUPS.mkdir(parents=True, exist_ok=True)
    backup = BACKUPS / datetime.now().strftime("%Y%m%d-%H%M%S")
    backup.mkdir()
    staging = Path(tempfile.mkdtemp(dir=BACKUPS))

    transaction = {"version": version, "backup": str(backup), "app_replaced": False,
                   "skins": [], "deckos": []}
    journal_written = False

    try:
        log("Preparing files")
        modes = {}
        with zipfile.ZipFile(package) as archive:
            for name in files:
                destination = staging / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(name) as source, destination.open("wb") as target:
                    shutil.copyfileobj(source, target)
                mode = (archive.getinfo(name).external_attr >> 16) & 0o777
                modes[name] = 0o775 if mode & 0o111 else 0o664

        if has_app:
            staged_app = staging / "payload/app/mixxx"
            staged_app.chmod(0o775)
            validate_mixxx(staged_app)

        for rel in deckos_files:
            staged = staging / "payload/deckos" / rel
            if staged.suffix == ".py":
                try:
                    py_compile.compile(str(staged), cfile=str(staged) + ".check", doraise=True)
                finally:
                    Path(str(staged) + ".check").unlink(missing_ok=True)

        current_app = APP / "mixxx"
        if not current_app.is_file():
            raise RuntimeError("Current Mixxx not found")

        log("Backing up Mixxx")
        shutil.copy2(current_app, backup / "mixxx")      # every backup is restorable
        transaction["app_replaced"] = has_app

        for name in skins:
            current = SKINS / name
            existed = current.exists()
            transaction["skins"].append({"name": name, "existed": existed})
            if existed:
                if current.is_symlink() or not current.is_dir():
                    raise RuntimeError("Unexpected skin destination")
                destination = backup / "skins" / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(current, destination)

        for rel in deckos_files:
            current = DECKOS / rel
            existed = current.is_file()
            if current.is_symlink() or (current.exists() and not existed):
                raise RuntimeError(f"Unexpected DeckOS destination: {rel}")
            transaction["deckos"].append({"path": rel, "existed": existed})
            if existed:
                destination = backup / "deckos" / rel
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(current, destination)

        atomic_json(JOURNAL, transaction)
        journal_written = True

        if has_app:
            log("Installing Mixxx")
            replacement = APP / "mixxx.new"
            shutil.copy2(staging / "payload/app/mixxx", replacement)
            replacement.chmod(0o775)
            os.replace(replacement, current_app)

        if skins:
            log("Installing skins")
        for name in skins:
            source = staging / "payload/resources/skins" / name
            destination = SKINS / name
            temporary = SKINS / (name + ".deckos-new")
            if not source.is_dir():
                raise RuntimeError("Incomplete skin")
            if temporary.exists():
                shutil.rmtree(temporary)
            shutil.copytree(source, temporary)
            if destination.exists():
                shutil.rmtree(destination)
            os.replace(temporary, destination)

        if deckos_files:
            log("Installing DeckOS files")
        for rel in deckos_files:
            name = "payload/deckos/" + rel
            destination = DECKOS / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_name(destination.name + ".deckos-new")
            shutil.copyfile(staging / name, temporary)
            temporary.chmod(modes[name])
            os.replace(temporary, destination)

        log("Final verification")
        if has_app:
            validate_mixxx(current_app)
        for name in skins:
            if not (SKINS / name).is_dir():
                raise RuntimeError(f"Skin missing: {name}")
        for rel in deckos_files:
            if sha256(DECKOS / rel) != sha256(staging / "payload/deckos" / rel):
                raise RuntimeError(f"DeckOS file mismatch: {rel}")

        JOURNAL.unlink()
        journal_written = False

        # Installed version: read by the Update Manager and shown on the boot
        # splash and the About page.
        try:
            atomic_json(INSTALLED_VERSION, {"version": version})
            INSTALLED_VERSION.chmod(0o644)
        except OSError as error:
            log(f"Warning: version not recorded ({error})")

        log(f"UPDATE SUCCESSFUL: {version}")
        prune_backups()
        log(f"Backup: {backup}")

    except Exception:
        log("ERROR — rolling back")
        if journal_written:
            try:
                restore_transaction()
                journal_written = False
            except Exception as error:
                log(f"CRITICAL ERROR DURING ROLLBACK: {error}")
        raise

    finally:
        shutil.rmtree(staging, ignore_errors=True)


# ----------------------------------------------------------------------------
# Manual restore of a backup (Maintenance > Restore a backup)
# ----------------------------------------------------------------------------
def restore_backup(folder):
    selected = Path(folder)
    BACKUPS.mkdir(parents=True, exist_ok=True)

    if selected.is_symlink():
        raise RuntimeError("A symbolic-link backup cannot be restored")
    selected = selected.resolve()
    if selected.parent != BACKUPS.resolve():
        raise RuntimeError("The backup must be directly inside backup-updates")
    if selected.name == "pre-v2":
        raise RuntimeError("The pre-v2 backup is protected")

    source_app = selected / "mixxx"
    source_skins = selected / "skins"
    source_deckos = selected / "deckos"

    if not source_app.is_file() or source_app.is_symlink():
        raise RuntimeError("Mixxx missing or invalid in the backup")

    skin_names = sorted(p.name for p in source_skins.iterdir() if p.is_dir()) if source_skins.is_dir() else []
    deckos_files = sorted(p.relative_to(source_deckos).as_posix()
                          for p in source_deckos.rglob("*") if p.is_file()) if source_deckos.is_dir() else []
    for rel in deckos_files:
        deckos_relative("payload/deckos/" + rel)

    log(f"Checking backup: {selected.name}")
    validate_mixxx(source_app)

    current_app = APP / "mixxx"
    if not current_app.is_file() or current_app.is_symlink():
        raise RuntimeError("The installed Mixxx is missing or invalid")

    # Safety copy of what is about to be replaced
    safety = BACKUPS / (datetime.now().strftime("%Y%m%d-%H%M%S") + "-pre-restore")
    temporary_safety = Path(tempfile.mkdtemp(prefix=".pre-restore-", dir=BACKUPS))
    try:
        shutil.copy2(current_app, temporary_safety / "mixxx")
        for name in skin_names:
            if (SKINS / name).is_dir():
                shutil.copytree(SKINS / name, temporary_safety / "skins" / name)
        for rel in deckos_files:
            if (DECKOS / rel).is_file():
                target = temporary_safety / "deckos" / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(DECKOS / rel, target)
        os.replace(temporary_safety, safety)
    except Exception:
        shutil.rmtree(temporary_safety, ignore_errors=True)
        raise
    log(f"Safety backup created: {safety.name}")

    try:
        log("Restoring Mixxx")
        staged = APP / "mixxx.restore-new"
        shutil.copy2(source_app, staged)
        staged.chmod(0o775)
        os.replace(staged, current_app)

        if skin_names:
            log("Restoring skins")
        for name in skin_names:
            staged = SKINS / (name + ".restore-new")
            if staged.exists():
                shutil.rmtree(staged)
            shutil.copytree(source_skins / name, staged)
            if (SKINS / name).exists():
                shutil.rmtree(SKINS / name)
            os.replace(staged, SKINS / name)

        if deckos_files:
            log("Restoring DeckOS files")
        for rel in deckos_files:
            target = DECKOS / rel
            staged = target.with_name(target.name + ".restore-new")
            shutil.copy2(source_deckos / rel, staged)
            os.replace(staged, target)

        log("Checking the restored version")
        validate_mixxx(current_app)
        log("RESTORE SUCCESSFUL")
        log(f"Restored from: {selected.name}")
        log(f"Safety backup: {safety}")

    except Exception as error:
        log("FAILED — going back to the previous version")
        try:
            shutil.copy2(safety / "mixxx", APP / "mixxx.rollback")
            os.replace(APP / "mixxx.rollback", current_app)
            for name in skin_names:
                if (safety / "skins" / name).is_dir():
                    if (SKINS / name).exists():
                        shutil.rmtree(SKINS / name)
                    shutil.copytree(safety / "skins" / name, SKINS / name)
            for rel in deckos_files:
                if (safety / "deckos" / rel).is_file():
                    shutil.copy2(safety / "deckos" / rel, DECKOS / rel)
            log("Previous version restored")
        except Exception as rollback_error:
            log(f"CRITICAL ERROR while going back: {rollback_error}")
        raise RuntimeError(f"Restore cancelled: {error}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", nargs="?", help="Folder containing the package")
    parser.add_argument("--recover", action="store_true", help="Recover an interrupted update")
    parser.add_argument("--restore-backup", help="Restore a full backup")
    parser.add_argument("--check", help="Only verify a package folder (signature, checksum, content)")
    args = parser.parse_args()

    try:
        if args.check:
            manifest, package = locate_package(args.check)
            files = inspect_archive(package)
            log(f"Package OK: DeckOS {manifest.get('version')} ({len(files)} files, signature verified)")
            return
        if args.restore_backup:
            restore_backup(args.restore_backup)
            return
        if args.recover:
            if not restore_transaction():
                log("No interrupted update to recover")
            return
        if not args.source:
            parser.error("A package folder is required")
        install(args.source)
    except Exception as error:
        log(f"FAILED: {error}")
        sys.exit(1)


if __name__ == "__main__":
    main()
