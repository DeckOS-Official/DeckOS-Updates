#!/usr/bin/env python3
import json
import os
import signal
import socket
import threading
import subprocess

SOCKET_DIR = "/run/deckos-control"
SOCKET_PATH = SOCKET_DIR + "/control.sock"
STOP = threading.Event()

from deckos_wifi import dispatch as wifi_dispatch

WIFI_ACTIONS = {"wifi_status", "wifi_scan", "wifi_saved", "wifi_connect",
                "wifi_connect_saved", "wifi_disconnect"}


def answer(raw):
    try:
        req = json.loads(raw.decode("utf-8"))
    except Exception:
        return {"ok": False, "error": "invalid_json"}
    if not isinstance(req, dict):
        return {"ok": False, "error": "request_must_be_object"}
    action = req.get("action")
    if action in WIFI_ACTIONS:
        params = {k: req.get(k) for k in ("ssid", "password", "name") if k in req}
        return wifi_dispatch(action, params)
    if action == "ping":
        return {"ok": True, "service": "Deck OS Control", "version": "0.2.0"}
    if action == "status":
        return {"ok": True, "service": "Deck OS Control", "version": "0.2.0",
                "state": "running", "available_actions": sorted(WIFI_ACTIONS) + ["ping", "status", "open_wifi", "open_updates"]}
    if action == "open_wifi":
        env = os.environ.copy()
        env["XDG_RUNTIME_DIR"] = "/run/user/1000"
        env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=/run/user/1000/bus"
        try:
            check = subprocess.run(["/usr/bin/systemctl", "--user", "is-active", "--quiet", "deckos-wifi-gui.service"], env=env, timeout=5)
            if check.returncode == 0:
                return {"ok": True, "action": "open_wifi", "state": "already_running"}
            result = subprocess.run(["/usr/bin/systemd-run", "--user", "--collect", "--unit=deckos-wifi-gui",
                                     "/home/deck/.local/bin/deckos-wifi-gui"], env=env,
                                    capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                return {"ok": False, "action": "open_wifi", "error": result.stderr.strip() or "launch_failed"}
            return {"ok": True, "action": "open_wifi", "state": "started"}
        except Exception as exc:
            return {"ok": False, "action": "open_wifi", "error": str(exc)}
    if action == "open_updates":
        env = os.environ.copy()
        env["XDG_RUNTIME_DIR"] = "/run/user/1000"
        env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=/run/user/1000/bus"
        env["DISPLAY"] = ":0"
        env["XAUTHORITY"] = "/home/deck/.Xauthority"
        try:
            check = subprocess.run(
                ["/usr/bin/systemctl", "--user", "is-active", "--quiet",
                 "deckos-update-manager.service"],
                env=env, timeout=5
            )
            if check.returncode == 0:
                return {"ok": True, "action": "open_updates",
                        "state": "already_running"}

            result = subprocess.run(
                ["/usr/bin/systemd-run", "--user", "--collect",
                 "--unit=deckos-update-manager",
                 "/usr/bin/python3",
                 "/home/deck/DeckOS/update-manager/update_manager_gui.py"],
                env=env, capture_output=True, text=True, timeout=10
            )
            if result.returncode != 0:
                return {"ok": False, "action": "open_updates",
                        "error": result.stderr.strip() or "launch_failed"}

            return {"ok": True, "action": "open_updates", "state": "started"}

        except Exception as exc:
            return {"ok": False, "action": "open_updates", "error": str(exc)}
    return {"ok": False, "error": "unknown_action"}


def client(conn):
    with conn:
        try:
            conn.settimeout(45)
            chunks = bytearray()
            while len(chunks) <= 8192:
                part = conn.recv(4096)
                if not part:
                    break
                chunks.extend(part)
                if b"\n" in part:
                    break
            if len(chunks) > 8192:
                result = {"ok": False, "error": "request_too_large"}
            else:
                result = answer(bytes(chunks).split(b"\n", 1)[0])
            conn.sendall((json.dumps(result, ensure_ascii=False) + "\n").encode("utf-8"))
        except OSError:
            pass


def stop(_sig, _frame):
    STOP.set()


def main():
    os.makedirs(SOCKET_DIR, mode=0o755, exist_ok=True)
    try:
        os.unlink(SOCKET_PATH)
    except FileNotFoundError:
        pass
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(SOCKET_PATH)
    os.chmod(SOCKET_PATH, 0o660)
    srv.listen(8)
    srv.settimeout(1)
    try:
        while not STOP.is_set():
            try:
                conn, _ = srv.accept()
            except socket.timeout:
                continue
            threading.Thread(target=client, args=(conn,), daemon=True).start()
    finally:
        srv.close()
        try:
            os.unlink(SOCKET_PATH)
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    main()
