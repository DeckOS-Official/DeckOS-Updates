#!/usr/bin/python3
"""DeckOS System Maintenance — shown at boot when an update is waiting.

Installs updates/pending with the DeckOS update engine, or restores a backup.
Closing it lets the boot continue to Mixxx (maintenance_boot.sh).
"""
import hashlib
import json
import os
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from PyQt6.QtCore import QProcess
from PyQt6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QProgressBar, QTextEdit

import deckos_ui as ui

DECKOS = Path("/home/deck/DeckOS")
ENGINE = DECKOS / "control/update_engine.py"
PENDING = DECKOS / "updates/pending"
INSTALLED = DECKOS / "updates/installed"
INSTALLED_VERSION = DECKOS / "updates/installed_version.json"
BACKUPS = DECKOS / "backup-updates"

STEPS = [
    ("verify", "Signature and package verification"),
    ("hash", "Integrity check (SHA-256)"),
    ("backup", "Backup of the current version"),
    ("mixxx", "Mixxx installation"),
    ("skins", "Skin installation"),
    ("deckos", "DeckOS files installation"),
    ("final", "Final verification"),
]
# engine output (English, with the former French wording kept for safety)
STAGES = [
    (("DeckOS Update Manager",), "verify", 5, "Verifying the package"),
    (("Signature verified",), "verify", 10, "Signature verified"),
    (("Preparing files", "Préparation des fichiers"), "hash", 25, "Checking integrity"),
    (("Backing up Mixxx", "Sauvegarde de Mixxx"), "backup", 40, "Backing up the current version"),
    (("Installing Mixxx", "Installation de Mixxx"), "mixxx", 55, "Installing Mixxx"),
    (("Installing skins", "Installation des skins"), "skins", 70, "Installing skins"),
    (("Installing DeckOS files",), "deckos", 85, "Installing DeckOS files"),
    (("Final verification", "Vérification finale"), "final", 95, "Final verification"),
    (("UPDATE SUCCESSFUL", "MISE À JOUR RÉUSSIE"), "final", 100, "Update installed"),
]


def read_version(path):
    try:
        return str(json.loads(Path(path).read_text(encoding="utf-8")).get("version", "?"))
    except Exception:
        return "?"


class Maintenance(ui.DeckOSWindow):

    def __init__(self):
        super().__init__("System Maintenance", "", mixxx_chrome=False)
        self.busy = False
        self.operation = "idle"
        self.package = None

        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(
            lambda: self.parse(bytes(self.process.readAllStandardOutput()).decode("utf-8", "replace")))
        self.process.readyReadStandardError.connect(
            lambda: self.parse(bytes(self.process.readAllStandardError()).decode("utf-8", "replace")))
        self.process.finished.connect(self.finished)
        self.process.errorOccurred.connect(self.process_error)

        self.content.addWidget(ui.Band("Update"))
        self.status_row = ui.Row("Checking…")
        self.status_row.label.setObjectName("RowValue")
        self.progress = self.status_row.add(QProgressBar())
        self.progress.setRange(0, 100)
        self.progress.setTextVisible(False)
        self.progress.setFixedWidth(360)
        self.percent = self.status_row.add(QLabel("0 %"))
        self.percent.setObjectName("RowSub")
        self.percent.setFixedWidth(44)
        self.content.addWidget(self.status_row)
        self.content.addSpacing(ui.ROW_GAP)

        self.content.addWidget(ui.Band("Steps"))
        self.steps = {}
        steps = ui.RowList()
        steps.lay.setSpacing(2)
        for i, (key, name) in enumerate(STEPS, 1):
            row = ui.Row(name, height=44)
            number = QLabel(f"{i:02d}")
            number.setObjectName("RowSub")
            number.setFixedWidth(34)
            row.layout().insertWidget(0, number)
            state = row.add(QLabel("PENDING"))
            state.setObjectName("Step")
            self.steps[key] = state
            steps.add(row)
        self.content.addWidget(steps)
        self.content.addSpacing(ui.ROW_GAP)

        self.content.addWidget(ui.Band("Log"))
        self.log_view = QTextEdit()
        self.log_view.setObjectName("Log")
        self.log_view.setReadOnly(True)
        self.content.addWidget(self.log_view, 1)
        self.content.addSpacing(ui.ROW_GAP)

        actions = QFrame()
        actions.setObjectName("Row")
        actions.setFixedHeight(ui.ROW_H)
        lay = QHBoxLayout(actions)
        lay.setContentsMargins(14, 0, 12, 0)
        lay.setSpacing(10)
        self.recovery_button = ui.action_button("RESTORE A BACKUP", "Action", self.start_recovery)
        lay.addWidget(self.recovery_button)
        lay.addStretch()
        self.continue_button = ui.action_button("START DECKOS", "Action", self.close)
        self.install_button = ui.action_button("INSTALL UPDATE", "Primary", self.start_install)
        self.restart_button = ui.action_button("RESTART", "Primary", self.restart)
        for b in (self.continue_button, self.install_button, self.restart_button):
            b.setFixedWidth(190)
            lay.addWidget(b)
        self.restart_button.hide()
        self.content.addWidget(actions)

        self.detect_package()

    # -- state ------------------------------------------------------------
    def can_leave(self):
        return not self.busy

    def log(self, text):
        self.log_view.append(text)
        bar = self.log_view.verticalScrollBar()
        bar.setValue(bar.maximum())

    def set_progress(self, value, text=None, state=""):
        self.progress.setValue(value)
        self.percent.setText(f"{value} %")
        if text is not None:
            self.status_row.label.setText(text)
        ui.restyle(self.status_row.label, state=state)
        self.status_row.label.setStyleSheet(
            {"ok": f"color:{ui.GREEN};", "error": f"color:{ui.RED};"}.get(state, ""))

    def set_step(self, key, state):
        label = self.steps.get(key)
        if label:
            label.setText({"busy": "IN PROGRESS", "ok": "DONE", "error": "FAILED"}.get(state, "PENDING"))
            ui.restyle(label, state=state)

    def set_buttons(self):
        self.recovery_button.setEnabled(not self.busy)
        self.continue_button.setEnabled(not self.busy)
        self.install_button.setEnabled(bool(self.package) and not self.busy)

    def detect_package(self):
        if (PENDING / "manifest.json").is_file():
            self.package = str(PENDING)
            new = read_version(PENDING / "manifest.json")
            old = read_version(INSTALLED_VERSION)
            self.set_progress(0, f"DeckOS {new} is ready to install")
            self.status_row.set_sub(f"Installed version: {old}   →   new version: {new}")
            self.set_hint("Do not switch off DeckOS during the installation")
        else:
            self.package = None
            self.set_progress(0, "No update waiting")
            self.status_row.set_sub(f"Installed version: {read_version(INSTALLED_VERSION)}")
            self.install_button.hide()
        self.set_buttons()

    # -- install ----------------------------------------------------------
    def start_install(self):
        if not self.package or self.busy:
            return
        self.busy = True
        self.operation = "install"
        self.log_view.clear()
        for key in self.steps:
            self.set_step(key, "")
        self.set_step("verify", "busy")
        self.set_progress(2, "Starting the installation…")
        self.set_buttons()
        self.process.start(sys.executable, [str(ENGINE), self.package])

    def parse(self, data):
        for line in data.splitlines():
            if not line.strip():
                continue
            self.log(line)
            for keywords, key, value, text in STAGES:
                if any(k in line for k in keywords):
                    order = [s for s, _ in STEPS]
                    for previous in order[:order.index(key)]:
                        self.set_step(previous, "ok")
                    self.set_step(key, "ok" if value == 100 else "busy")
                    self.set_progress(value, text)
            if any(k in line for k in ("ERROR", "FAILED", "ERREUR", "ÉCHEC")):
                self.status_row.set_sub(line.strip(), "error")

    def process_error(self, _error):
        if self.process.state() != QProcess.ProcessState.NotRunning:
            return
        self.busy = False
        self.log("Unable to start the update engine: " + self.process.errorString())
        self.set_progress(0, "The update engine could not start", "error")
        self.set_buttons()

    def finished(self, code, exit_status):
        operation, self.operation = self.operation, "idle"
        self.busy = False
        ok = code == 0 and exit_status == QProcess.ExitStatus.NormalExit
        if ok and operation == "install":
            try:
                self.archive_installed_package()
            except Exception as error:
                self.log("Archive warning: " + str(error))
            for key in self.steps:
                self.set_step(key, "ok")
            self.set_progress(100, f"DeckOS {read_version(INSTALLED_VERSION)} installed", "ok")
            self.status_row.set_sub("Restart to start the new version", "ok")
            self.package = None
            self.install_button.hide()
            self.continue_button.hide()
            self.restart_button.show()
        elif ok and operation == "restore":
            self.set_progress(100, "Backup restored", "ok")
            self.status_row.set_sub("Mixxx and the skins were restored. Settings were kept.", "ok")
        else:
            current = next((k for k, s in self.steps.items() if s.text() == "IN PROGRESS"), None)
            if current:
                self.set_step(current, "error")
            self.set_progress(self.progress.value(), "The operation failed", "error")
            self.log(f"The update engine stopped with code {code}. The previous version was kept.")
        self.set_buttons()

    def archive_installed_package(self):
        manifest_path = PENDING / "manifest.json"
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        name = manifest.get("package")
        if not isinstance(name, str) or Path(name).name != name:
            raise RuntimeError("Invalid package name in the manifest")
        package_path = PENDING / name
        expected = str(manifest.get("sha256", "")).lower()

        def digest(path):
            h = hashlib.sha256()
            with path.open("rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            return h.hexdigest()

        if len(expected) != 64 or digest(package_path) != expected:
            raise RuntimeError("SHA-256 mismatch on the installed package")
        INSTALLED.mkdir(parents=True, exist_ok=True)
        temporary = Path(tempfile.mkdtemp(prefix=".archive-", dir=INSTALLED))
        destination = INSTALLED / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        try:
            shutil.copy2(package_path, temporary / name)
            shutil.copy2(manifest_path, temporary / "manifest.json")
            signature = PENDING / "manifest.json.sig"
            if signature.is_file():
                shutil.copy2(signature, temporary / "manifest.json.sig")
            if digest(temporary / name) != expected:
                raise RuntimeError("Archive SHA-256 verification failed")
            with zipfile.ZipFile(temporary / name) as archive:
                bad = archive.testzip()
                if bad:
                    raise RuntimeError("Damaged ZIP archive: " + bad)
            os.replace(temporary, destination)
        except Exception:
            shutil.rmtree(temporary, ignore_errors=True)
            raise
        # the update is archived: empty the pending folder completely so the
        # Update Manager can prepare the next update
        shutil.rmtree(PENDING, ignore_errors=True)
        # keep only the two most recent archived packages
        archives = sorted(p for p in INSTALLED.iterdir() if p.is_dir() and not p.name.startswith("."))
        for old in archives[:-2]:
            shutil.rmtree(old, ignore_errors=True)
        self.log("Installed package archived: " + destination.name)

    # -- recovery ---------------------------------------------------------
    def start_recovery(self):
        if self.busy:
            return
        backups = []
        if BACKUPS.is_dir():
            for p in sorted(BACKUPS.iterdir(), reverse=True):
                if (p.is_dir() and not p.is_symlink() and not p.name.startswith(".")
                        and p.name != "pre-v2" and (p / "mixxx").is_file() and (p / "skins").is_dir()):
                    try:
                        stamp = datetime.strptime(p.name[:15], "%Y%m%d-%H%M%S").strftime("%d %b %Y   %H:%M")
                    except ValueError:
                        stamp = p.name
                    kind = "   (before a restore)" if "pre-restore" in p.name else ""
                    backups.append((f"Backup of {stamp}{kind}", p))
        if not backups:
            ui.inform(self, "Restore a backup", "No backup is available yet.", "Action")
            return
        folder = ui.choose(self, "Restore a backup",
                           "Mixxx and the skins return to the selected backup. "
                           "Your Mixxx settings and library are kept.", backups)
        if folder is None:
            return
        if not ui.ask(self, "Restore a backup", f"Restore {folder.name}?\n\n"
                      "A safety copy of the current version is made first.",
                      [("CANCEL", "Action", False), ("RESTORE", "Primary", True)]):
            return
        self.busy = True
        self.operation = "restore"
        self.log_view.clear()
        self.set_progress(10, "Restoring the backup…")
        self.set_buttons()
        self.process.start(sys.executable, [str(ENGINE), "--restore-backup", str(folder)])

    def restart(self):
        self.set_progress(100, "Restarting DeckOS…", "ok")
        if not QProcess.startDetached("systemctl", ["reboot"]):
            self.log("ERROR: the restart could not be started.")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("DeckOS Maintenance")
    ui.setup_app(app)
    window = Maintenance()
    window.present()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
