#!/usr/bin/python3
"""DeckOS shared UI kit.

Every DeckOS tool (Wi-Fi, Update Manager, Maintenance) is drawn with the same
geometry and colours as the Mixxx DeckOS skin's SETTINGS page, so opening one
of them looks like opening another Settings sub-page:

* the five Mixxx tabs on top (SETTINGS active) and the Settings sidebar
  (System active) are redrawn at the exact same pixels; tapping one of them
  closes the tool and forwards the tap to Mixxx underneath;
* the Mixxx deck strip at the bottom of the screen is left uncovered.

All sizes are in pixels, like the skin (ScaleFactor 1), so it lines up at
1920x1080 and 1280x800 alike.
"""
import ctypes
import ctypes.util
import time

from PyQt6.QtCore import Qt, QEventLoop, QTimer, QRectF, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QGuiApplication
from PyQt6.QtWidgets import (
    QApplication, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget
)

# ----------------------------------------------------------------------------
# Palette and geometry measured on the Mixxx DeckOS skin (Settings page)
# ----------------------------------------------------------------------------
BLACK = "#000000"
PAGE = "#212121"
SIDEBAR = "#1a1a1a"
SIDE_ITEM = "#262626"
SIDE_ACTIVE = "#2b4f86"
HEADER = "#3a3a3a"
BAND = "#303030"
BAND_LINE = "#4a4a4a"
ROW = "#2b2b2b"
TAB_BORDER = "#5a5a5a"
BLUE = "#2f86ff"
BLUE_BORDER = "#2f6fe6"
BLUE_FILL = "#007be8"
WHITE = "#ffffff"
SECTION_TEXT = "#c4c4c4"
HINT = "#a8a8a8"
MUTED = "#6f6f6f"
GREEN = "#3ecf7a"
RED = "#ff6159"
RED_BORDER = "#c2453d"

TOPBAR_H = 60          # tabs 8..47, black, 1px #1e1e1e line at 56, content at 60
TAB_H = 40
SIDEBAR_W = 148
SIDE_ITEM_H = 52
GUTTER = 8             # black gap between sidebar and page
HEADER_H = 36
ROW_H = 67
ROW_GAP = 7
DECK_STRIP_H = 64      # Mixxx deck strip left visible under the tool

MIXXX_TABS = ["PLAY", "BROWSE", "SAMPLER", "LEVELS", "SETTINGS"]
MIXXX_SIDE = [("⚙", "General"), ("☰", "Library"), ("⌘", "Device"),
              ("♪", "Audio"), ("▣", "System"), ("ⓘ", "About")]

STYLE = f"""
* {{ font-family: 'Inter', 'DejaVu Sans', sans-serif; }}
QWidget#Root, QWidget#Body, QWidget#Page {{ background:{BLACK}; }}
QLabel {{ background:transparent; color:{WHITE}; }}

QPushButton#Tab {{
    border:1px solid {TAB_BORDER}; border-radius:3px;
    background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #363636, stop:1 #0b0b0b);
    color:{BLUE}; font-size:15px; font-weight:700;
}}
QPushButton#Tab[active="true"] {{ color:{WHITE}; }}
QFrame#TopLine {{ background:#1e1e1e; }}

QWidget#Sidebar {{ background:{SIDEBAR}; }}
QPushButton#SideItem {{
    background:{SIDE_ITEM}; border:none; border-bottom:2px solid {BLACK};
    color:{WHITE}; font-size:16px; font-weight:500;
}}
QPushButton#SideItem[active="true"] {{ background:{SIDE_ACTIVE}; }}

QFrame#Header {{ background:{HEADER}; }}
QPushButton#HeaderBack {{
    background:transparent; border:none; color:{WHITE};
    font-size:16px; font-weight:500; text-align:left; padding:0 14px;
}}
QPushButton#HeaderBack:pressed {{ color:{BLUE}; }}
QLabel#HeaderHint {{ color:{HINT}; font-size:12px; padding-right:12px; }}
QLabel#HeaderHint[state="ok"] {{ color:{GREEN}; }}
QLabel#HeaderHint[state="error"] {{ color:{RED}; }}

QFrame#Band {{ background:{BAND}; border-top:1px solid {BAND_LINE}; }}
QLabel#BandTitle {{ color:{SECTION_TEXT}; font-size:12px; font-weight:700; letter-spacing:1px; padding-left:14px; }}
QLabel#BandHint {{ color:{HINT}; font-size:12px; padding-right:14px; }}

QFrame#Row {{ background:{ROW}; }}
QLabel#RowLabel {{ color:{WHITE}; font-size:15px; font-weight:500; }}
QLabel#RowValue {{ color:{WHITE}; font-size:18px; font-weight:600; }}
QLabel#RowSub {{ color:{HINT}; font-size:12px; }}
QLabel#RowSub[state="ok"] {{ color:{GREEN}; }}
QLabel#RowSub[state="error"] {{ color:{RED}; }}
QLabel#RowSub[state="busy"] {{ color:{BLUE}; }}
QLabel#Step {{ color:{MUTED}; font-size:12px; font-weight:700; letter-spacing:1px; }}
QLabel#Step[state="busy"] {{ color:{BLUE}; }}
QLabel#Step[state="ok"] {{ color:{GREEN}; }}
QLabel#Step[state="error"] {{ color:{RED}; }}

QPushButton#Action, QPushButton#Primary, QPushButton#Danger, QPushButton#Seg, QPushButton#Key {{
    min-height:42px; max-height:42px; font-size:13px; font-weight:700; padding:0 16px;
}}
QPushButton#Action {{ background:{BLACK}; border:1px solid {BLUE_BORDER}; color:{BLUE}; min-width:96px; }}
QPushButton#Action:pressed {{ background:#0a1e39; }}
QPushButton#Action:disabled {{ border-color:#2b3f4d; color:#4f6270; }}
QPushButton#Primary {{ background:{BLUE_FILL}; border:1px solid {BLUE_FILL}; color:{WHITE}; min-width:96px; }}
QPushButton#Primary:pressed {{ background:#0a5fb0; }}
QPushButton#Primary:disabled {{ background:#16324d; border-color:#16324d; color:#5c707d; }}
QPushButton#Danger {{ background:{BLACK}; border:1px solid {RED_BORDER}; color:{RED}; min-width:96px; }}
QPushButton#Danger:pressed {{ background:#3a1310; }}
QPushButton#Danger:disabled {{ border-color:#4d2b2b; color:#705c5c; }}
QPushButton#Seg {{ background:{BLACK}; border:none; color:{WHITE}; min-width:72px; }}
QPushButton#Seg[active="true"] {{ background:{BLUE_FILL}; }}

QProgressBar {{ background:{BLACK}; border:1px solid {BAND_LINE}; min-height:10px; max-height:10px; }}
QProgressBar::chunk {{ background:{BLUE_FILL}; }}

QScrollArea {{ background:transparent; border:none; }}
QScrollArea > QWidget > QWidget {{ background:transparent; }}
QScrollBar:vertical {{ background:{SIDEBAR}; width:12px; margin:0; }}
QScrollBar::handle:vertical {{ background:{BAND_LINE}; min-height:40px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background:none; }}

QTextEdit#Log {{
    background:{SIDEBAR}; border:none; color:{SECTION_TEXT};
    font-family:'DejaVu Sans Mono'; font-size:12px; padding:8px 12px;
}}

QWidget#Overlay {{ background:rgba(0,0,0,185); }}
QFrame#Dialog {{ background:{PAGE}; border:1px solid {BAND_LINE}; }}
QLabel#DialogText {{ color:{WHITE}; font-size:15px; padding:4px 14px; }}
QLineEdit#Entry {{
    background:{BLACK}; color:{WHITE}; border:1px solid {BAND_LINE};
    font-size:20px; padding:6px 12px; min-height:40px;
    selection-background-color:{BLUE_FILL};
}}
QLineEdit#Entry:focus {{ border-color:{BLUE_BORDER}; }}
QPushButton#Key {{
    background:{ROW}; border:none; color:{WHITE}; font-size:18px; font-weight:500;
    min-height:50px; max-height:50px; padding:0;
}}
QPushButton#Key:pressed {{ background:{SIDE_ACTIVE}; }}
QPushButton#Key[active="true"] {{ background:{BLUE_FILL}; }}
QPushButton#Key[kind="wide"] {{ font-size:13px; font-weight:700; }}
"""


def setup_app(app):
    app.setStyle("Fusion")
    font = QFont("Inter")
    font.setPixelSize(14)
    app.setFont(font)
    app.setStyleSheet(STYLE)


def restyle(widget, **props):
    """Change dynamic properties used by the stylesheet and repaint."""
    for key, value in props.items():
        widget.setProperty(key, value)
    widget.style().unpolish(widget)
    widget.style().polish(widget)
    widget.update()


def _x11_click(x, y):
    """Synthetic left click on display :0 (no xdotool on DeckOS)."""
    lib = ctypes.util.find_library("X11")
    if not lib:
        return
    X = ctypes.cdll.LoadLibrary(lib)
    X.XOpenDisplay.restype = ctypes.c_void_p
    X.XDefaultRootWindow.restype = ctypes.c_ulong
    dpy = X.XOpenDisplay(None)
    if not dpy:
        return
    d = ctypes.c_void_p(dpy)
    root = X.XDefaultRootWindow(d)

    def translate(win):
        rx, ry, child = ctypes.c_int(), ctypes.c_int(), ctypes.c_ulong()
        X.XTranslateCoordinates(d, ctypes.c_ulong(root), ctypes.c_ulong(win), x, y,
                                ctypes.byref(rx), ctypes.byref(ry), ctypes.byref(child))
        return child.value, rx.value, ry.value

    win = root
    while True:
        child, _, _ = translate(win)
        if not child:
            break
        win = child
    _, wx, wy = translate(win)

    class Button(ctypes.Structure):
        _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                    ("display", ctypes.c_void_p), ("window", ctypes.c_ulong), ("root", ctypes.c_ulong),
                    ("subwindow", ctypes.c_ulong), ("time", ctypes.c_ulong), ("x", ctypes.c_int),
                    ("y", ctypes.c_int), ("x_root", ctypes.c_int), ("y_root", ctypes.c_int),
                    ("state", ctypes.c_uint), ("button", ctypes.c_uint), ("same_screen", ctypes.c_int)]

    class Event(ctypes.Union):
        _fields_ = [("xbutton", Button), ("pad", ctypes.c_long * 24)]

    X.XWarpPointer(d, 0, ctypes.c_ulong(root), 0, 0, 0, 0, x, y)
    X.XFlush(d)
    time.sleep(0.05)
    for etype, mask, state in ((4, 1 << 2, 0), (5, 1 << 3, 1 << 8)):
        ev = Event()
        b = ev.xbutton
        b.type, b.display, b.window, b.root = etype, dpy, win, root
        b.x, b.y, b.x_root, b.y_root = wx, wy, x, y
        b.button, b.same_screen, b.state = 1, 1, state
        X.XSendEvent(d, ctypes.c_ulong(win), 1, mask, ctypes.byref(ev))
        X.XFlush(d)
        time.sleep(0.05)
    X.XCloseDisplay(d)


# ----------------------------------------------------------------------------
# Building blocks
# ----------------------------------------------------------------------------
def action_button(text, kind="Action", slot=None):
    button = QPushButton(text)
    button.setObjectName(kind)
    button.setCursor(Qt.CursorShape.PointingHandCursor)
    if slot:
        button.clicked.connect(slot)
    return button


class Band(QFrame):
    """Section title band (e.g. 'USB STORAGE')."""

    def __init__(self, title, hint=""):
        super().__init__()
        self.setObjectName("Band")
        self.setFixedHeight(31)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.title = QLabel(title.upper())
        self.title.setObjectName("BandTitle")
        self.hint = QLabel(hint)
        self.hint.setObjectName("BandHint")
        lay.addWidget(self.title)
        lay.addStretch()
        lay.addWidget(self.hint)


class Row(QFrame):
    """A Settings row: label (+ optional sub-line) on the left, controls on the right."""

    def __init__(self, label="", sub="", height=ROW_H):
        super().__init__()
        self.setObjectName("Row")
        self.setFixedHeight(height)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 0, 12, 0)
        lay.setSpacing(10)
        text = QVBoxLayout()
        text.setSpacing(2)
        text.addStretch()
        self.label = QLabel(label)
        self.label.setObjectName("RowLabel")
        text.addWidget(self.label)
        self.sub = QLabel(sub)
        self.sub.setObjectName("RowSub")
        self.sub.setVisible(bool(sub))
        text.addWidget(self.sub)
        text.addStretch()
        lay.addLayout(text, 1)
        self.controls = QHBoxLayout()
        self.controls.setSpacing(10)
        lay.addLayout(self.controls)

    def add(self, widget):
        self.controls.addWidget(widget)
        return widget

    def set_sub(self, text, state=""):
        self.sub.setText(text)
        self.sub.setVisible(bool(text))
        restyle(self.sub, state=state)


class RowList(QWidget):
    """Vertical stack of rows separated by the skin's 7px black gaps."""

    def __init__(self):
        super().__init__()
        self.setObjectName("Page")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(ROW_GAP)
        self.lay.addStretch()

    def add(self, widget):
        self.lay.insertWidget(self.lay.count() - 1, widget)
        return widget

    def clear(self):
        while self.lay.count() > 1:
            item = self.lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()


def scroll(widget):
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    area.setWidget(widget)
    return area


class SignalBars(QWidget):
    """Four-bar Wi-Fi strength indicator."""

    def __init__(self, percent=0):
        super().__init__()
        self.percent = percent or 0
        self.setFixedSize(34, 24)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        level = 0 if self.percent <= 0 else 1 + min(3, self.percent // 25)
        for i in range(4):
            h = 6 + i * 6
            rect = QRectF(i * 9, 24 - h, 6, h)
            p.fillRect(rect, QColor(BLUE if i < level else BAND_LINE))


# ----------------------------------------------------------------------------
# Window chrome
# ----------------------------------------------------------------------------
class DeckOSWindow(QWidget):
    """Full-screen tool window that mimics the Mixxx Settings page.

    mixxx_chrome=True  : Mixxx tabs + Settings sidebar, deck strip left visible.
    mixxx_chrome=False : stand-alone (boot maintenance, Mixxx not running).
    """

    def __init__(self, title, hint="", back_label="System", mixxx_chrome=True):
        super().__init__()
        self.mixxx_chrome = mixxx_chrome
        self._closing = False
        self.setObjectName("Root")
        self.setWindowTitle("DeckOS " + title)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._topbar(title))

        body = QWidget()
        body.setObjectName("Body")
        body_lay = QHBoxLayout(body)
        body_lay.setContentsMargins(0, 0, 0, 0)
        body_lay.setSpacing(GUTTER)
        if mixxx_chrome:
            body_lay.addWidget(self._sidebar())

        page = QWidget()
        page.setObjectName("Page")
        page_lay = QVBoxLayout(page)
        page_lay.setContentsMargins(0, 0, 0, 0)
        page_lay.setSpacing(14)

        header = QFrame()
        header.setObjectName("Header")
        header.setFixedHeight(HEADER_H)
        header_lay = QHBoxLayout(header)
        header_lay.setContentsMargins(0, 0, 0, 0)
        if mixxx_chrome:
            back = QPushButton(f"‹   {back_label}   /   {title}")
            back.setObjectName("HeaderBack")
            back.clicked.connect(self.back_to_mixxx)
        else:
            back = QLabel(f"   ▣   {title}")
            back.setStyleSheet("font-size:16px;font-weight:600;")
        header_lay.addWidget(back)
        header_lay.addStretch()
        self.hint = QLabel(hint)
        self.hint.setObjectName("HeaderHint")
        header_lay.addWidget(self.hint)
        page_lay.addWidget(header)

        self.content = QVBoxLayout()
        self.content.setContentsMargins(0, 0, 0, 0)
        self.content.setSpacing(0)
        page_lay.addLayout(self.content, 1)
        body_lay.addWidget(page, 1)
        outer.addWidget(body, 1)

    # -- chrome -----------------------------------------------------------
    def _topbar(self, title):
        bar = QWidget()
        bar.setObjectName("Root")
        bar.setFixedHeight(TOPBAR_H)
        lay = QVBoxLayout(bar)
        lay.setContentsMargins(10, 8, 10, 0)
        lay.setSpacing(0)
        tabs = QHBoxLayout()
        tabs.setSpacing(9)
        names = MIXXX_TABS if self.mixxx_chrome else ["DECKOS"]
        for name in names:
            tab = QPushButton(name)
            tab.setObjectName("Tab")
            tab.setFixedHeight(TAB_H)
            tab.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            active = name == "SETTINGS" or not self.mixxx_chrome
            tab.setProperty("active", "true" if active else "false")
            if self.mixxx_chrome:
                if name == "SETTINGS":
                    tab.clicked.connect(self.back_to_mixxx)
                else:
                    tab.clicked.connect(lambda _=False, t=tab: self.forward_to_mixxx(t))
            else:
                tab.setEnabled(False)
            tabs.addWidget(tab)
        lay.addLayout(tabs)
        lay.addSpacing(8)
        line = QFrame()
        line.setObjectName("TopLine")
        line.setFixedHeight(1)
        lay.addWidget(line)
        lay.addStretch()
        return bar

    def _sidebar(self):
        side = QWidget()
        side.setObjectName("Sidebar")
        side.setFixedWidth(SIDEBAR_W)
        lay = QVBoxLayout(side)
        lay.setContentsMargins(0, 1, 0, 0)
        lay.setSpacing(0)
        for icon, name in MIXXX_SIDE:
            item = QPushButton(f"{icon}  {name}")
            item.setObjectName("SideItem")
            item.setFixedHeight(SIDE_ITEM_H + 2)
            item.setProperty("active", "true" if name == "System" else "false")
            if name == "System":
                item.clicked.connect(self.back_to_mixxx)
            else:
                item.clicked.connect(lambda _=False, w=item: self.forward_to_mixxx(w))
            lay.addWidget(item)
        lay.addStretch()
        return side

    # -- showing / leaving -------------------------------------------------
    def present(self):
        screen = QGuiApplication.primaryScreen().geometry()
        if self.mixxx_chrome:
            self.setGeometry(screen.x(), screen.y(), screen.width(), screen.height() - DECK_STRIP_H)
            self.show()
        else:
            self.showFullScreen()
        self.raise_()
        self.activateWindow()

    def can_leave(self):
        """Override to refuse leaving while an operation is running."""
        return True

    def back_to_mixxx(self):
        if self.can_leave():
            self.close()

    def forward_to_mixxx(self, widget):
        """Close the tool and replay the tap on the same Mixxx control."""
        if not self.can_leave() or self._closing:
            return
        self._closing = True
        center = widget.mapToGlobal(widget.rect().center())
        self.hide()
        QApplication.processEvents()

        def replay():
            try:
                _x11_click(center.x(), center.y())
            finally:
                QApplication.quit()

        QTimer.singleShot(180, replay)

    def closeEvent(self, event):
        if not self._closing and not self.can_leave():
            event.ignore()
            return
        event.accept()

    def set_hint(self, text, state=""):
        self.hint.setText(text)
        restyle(self.hint, state=state)


# ----------------------------------------------------------------------------
# In-window dialogs (touch friendly, no OS dialogs)
# ----------------------------------------------------------------------------
class Overlay(QWidget):
    finished = pyqtSignal(object)

    def __init__(self, parent, title, width=760):
        super().__init__(parent)
        self.setObjectName("Overlay")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setGeometry(parent.rect())
        self.result_value = None
        self._loop = None
        outer = QVBoxLayout(self)
        outer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.dialog = QFrame()
        self.dialog.setObjectName("Dialog")
        self.dialog.setFixedWidth(min(width, parent.width() - 40))
        self.dialog.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Maximum)
        self.body = QVBoxLayout(self.dialog)
        self.body.setContentsMargins(0, 0, 0, 14)
        self.body.setSpacing(12)
        header = QFrame()
        header.setObjectName("Header")
        header.setFixedHeight(HEADER_H)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(14, 0, 14, 0)
        t = QLabel(title)
        t.setStyleSheet("font-size:16px;font-weight:600;")
        hl.addWidget(t)
        self.body.addWidget(header)
        outer.addWidget(self.dialog)

    def add_text(self, text):
        label = QLabel(text)
        label.setObjectName("DialogText")
        label.setWordWrap(True)
        label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        self.body.addWidget(label)
        return label

    def add_buttons(self, buttons):
        """buttons: list of (text, kind, value)."""
        row = QHBoxLayout()
        row.setContentsMargins(14, 4, 14, 0)
        row.setSpacing(10)
        row.addStretch()
        for text, kind, value in buttons:
            row.addWidget(action_button(text, kind, lambda _=False, v=value: self.done(v)))
        self.body.addLayout(row)

    def done(self, value):
        self.result_value = value
        self.hide()
        self.finished.emit(value)
        if self._loop:
            self._loop.quit()

    def run(self):
        self.show()
        self.raise_()
        self._loop = QEventLoop()
        self._loop.exec()
        self.deleteLater()
        return self.result_value


def ask(parent, title, text, buttons=None):
    """Blocking confirmation. Returns the value of the pressed button."""
    buttons = buttons or [("CANCEL", "Action", False), ("OK", "Primary", True)]
    ov = Overlay(parent, title)
    ov.add_text(text)
    ov.add_buttons(buttons)
    return ov.run()


def inform(parent, title, text, kind="Primary"):
    return ask(parent, title, text, [("OK", kind, True)])


def choose(parent, title, text, choices):
    """Pick one entry from a list of (label, value). Returns value or None."""
    ov = Overlay(parent, title, width=860)
    if text:
        ov.add_text(text)
    rows = RowList()
    for label, value in choices:
        row = Row(label, height=58)
        row.add(action_button("SELECT", "Action", lambda _=False, v=value: ov.done(v)))
        rows.add(row)
    area = scroll(rows)
    area.setFixedHeight(min(len(choices), 5) * (58 + ROW_GAP) + 4)
    ov.body.addWidget(area)
    ov.add_buttons([("CANCEL", "Action", None)])
    return ov.run()


LAYOUTS = {
    "QWERTY": ["1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"],
    "AZERTY": ["1234567890", "azertyuiop", "qsdfghjklm", "wxcvbn"],
}
SYMBOLS = ["1234567890", "!@#$%^&*()", "-_=+[]{};:", "'\",.<>/?\\|", "`~€£"]


class PasswordDialog(Overlay):
    """Full on-screen keyboard (QWERTY / AZERTY / symbols)."""

    def __init__(self, parent, ssid, layout="QWERTY"):
        super().__init__(parent, f"Wi-Fi password  —  {ssid}", width=980)
        self.layout_name = layout
        self.shift = False
        self.symbols = False
        top = QHBoxLayout()
        top.setContentsMargins(14, 0, 14, 0)
        top.setSpacing(10)
        self.entry = QLineEdit()
        self.entry.setObjectName("Entry")
        self.entry.setEchoMode(QLineEdit.EchoMode.Password)
        self.entry.setPlaceholderText("Enter password")
        self.entry.returnPressed.connect(lambda: self.done(self.entry.text()))
        top.addWidget(self.entry, 1)
        self.show_button = action_button("SHOW", "Seg", self.toggle_show)
        top.addWidget(self.show_button)
        self.body.addLayout(top)
        self.grid_host = QWidget()
        self.grid = QGridLayout(self.grid_host)
        self.grid.setContentsMargins(14, 0, 14, 0)
        self.grid.setHorizontalSpacing(6)
        self.grid.setVerticalSpacing(6)
        self.body.addWidget(self.grid_host)
        self.add_buttons([("CANCEL", "Action", None), ("CONNECT", "Primary", "__entry__")])
        self.build()
        self.entry.setFocus()

    def done(self, value):
        super().done(self.entry.text() if value == "__entry__" else value)

    def toggle_show(self):
        visible = self.entry.echoMode() == QLineEdit.EchoMode.Password
        self.entry.setEchoMode(QLineEdit.EchoMode.Normal if visible else QLineEdit.EchoMode.Password)
        restyle(self.show_button, active="true" if visible else "false")

    def key(self, text, kind="", slot=None, active=False):
        b = QPushButton(text)
        b.setObjectName("Key")
        if kind:
            b.setProperty("kind", kind)
        if active:
            b.setProperty("active", "true")
        b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.clicked.connect(slot or (lambda _=False, t=text: self.type(t)))
        return b

    def build(self):
        while self.grid.count():
            w = self.grid.takeAt(0).widget()
            if w:
                w.deleteLater()
        rows = SYMBOLS if self.symbols else LAYOUTS[self.layout_name]
        cols = 20  # half-key resolution so rows can be staggered
        for r, chars in enumerate(rows):
            offset = (cols - 2 * len(chars)) // 2
            for i, ch in enumerate(chars):
                label = ch.upper() if (self.shift and ch.isalpha()) else ch
                self.grid.addWidget(self.key(label), r, offset + 2 * i, 1, 2)
        r = len(rows)
        if not self.symbols:
            # shift / backspace frame the last letter row
            last = len(rows) - 1
            self.grid.addWidget(self.key("SHIFT", "wide", self.toggle_shift, self.shift), last, 0, 1, 3)
            self.grid.addWidget(self.key("⌫", "wide", self.backspace), last, cols - 3, 1, 3)
        else:
            self.grid.addWidget(self.key("⌫", "wide", self.backspace), r - 1, cols - 3, 1, 3)
        self.grid.addWidget(self.key("ABC" if self.symbols else "#+=", "wide", self.toggle_symbols), r, 0, 1, 3)
        self.grid.addWidget(self.key("SPACE", "wide", lambda: self.type(" ")), r, 3, 1, 12)
        other = "AZERTY" if self.layout_name == "QWERTY" else "QWERTY"
        self.grid.addWidget(self.key(other, "wide", self.toggle_layout), r, 15, 1, 5)
        for c in range(cols):
            self.grid.setColumnStretch(c, 1)

    def type(self, text):
        self.entry.insert(text)
        if self.shift:
            self.shift = False
            self.build()

    def backspace(self):
        self.entry.backspace()

    def toggle_shift(self):
        self.shift = not self.shift
        self.build()

    def toggle_symbols(self):
        self.symbols = not self.symbols
        self.build()

    def toggle_layout(self):
        self.layout_name = "AZERTY" if self.layout_name == "QWERTY" else "QWERTY"
        self.build()
