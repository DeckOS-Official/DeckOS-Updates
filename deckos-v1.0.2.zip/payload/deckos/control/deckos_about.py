#!/usr/bin/python3
"""Generate the DeckOS skin pages that show live system information.

Run by ~/DeckOS/launch.sh before every Mixxx start. It writes two skin
templates with the real, current versions:

  templates/deckos_about.xml        Settings > About
  templates/deckos_system_rows.xml  Settings > System: Wi-Fi / Software Update rows

The skin ships a copy of both files, so Mixxx still loads if this script fails.
"""
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from xml.sax.saxutils import escape

DECKOS = Path("/home/deck/DeckOS")
SKIN = DECKOS / "resources/skins/DeckOS"
TEMPLATES = SKIN / "templates"
VERSION_FILE = DECKOS / "updates/installed_version.json"

# Built into the DeckOS Mixxx binary (not packaged by Debian).
ENGINE_NAME = "DeckOS DJ Engine"
MIXXX_BASE = "2.5.6"
DJINTEROP = "0.24.3"
SOURCE_URL = "github.com/DeckOS-Official/DeckOS-Updates"

# (id, name, version source, licence, website, logo image or None)
# version source: "dpkg:<package>", "kernel", "os", or a fixed string
COMPONENTS = [
    ("mixxx", "Mixxx", MIXXX_BASE, "GPL-2.0-or-later", "mixxx.org", "about/mixxx.png"),
    ("linux", "Linux kernel", "kernel", "GPL-2.0", "kernel.org", None),
    ("debian", "Debian GNU/Linux", "os", "DFSG free software", "debian.org", "about/debian.png"),
    ("qt", "Qt", "dpkg:libqt6core6t64", "LGPL-3.0", "qt.io", "about/qt.png"),
    ("ffmpeg", "FFmpeg", "dpkg:libavcodec61", "LGPL-2.1-or-later", "ffmpeg.org", None),
    ("portaudio", "PortAudio", "dpkg:libportaudio2", "MIT", "portaudio.com", None),
    ("alsa", "ALSA", "dpkg:libasound2t64", "LGPL-2.1-or-later", "alsa-project.org", None),
    ("taglib", "TagLib", "dpkg:libtag2", "LGPL-2.1 / MPL-1.1", "taglib.org", None),
    ("soundtouch", "SoundTouch", "dpkg:libsoundtouch1", "LGPL-2.1", "surina.net", None),
    ("rubberband", "Rubber Band", "dpkg:librubberband2", "GPL-2.0-or-later", "breakfastquay.com", None),
    ("chromaprint", "Chromaprint", "dpkg:libchromaprint1", "LGPL-2.1-or-later", "acoustid.org", None),
    ("djinterop", "libdjinterop", DJINTEROP, "LGPL-3.0", "github.com/xsco", None),
    ("xorg", "X.Org Server", "dpkg:xserver-xorg-core", "MIT", "x.org", None),
    ("openbox", "Openbox", "dpkg:openbox", "GPL-2.0-or-later", "openbox.org", None),
    ("nm", "NetworkManager", "dpkg:network-manager", "GPL-2.0-or-later", "networkmanager.dev", None),
    ("plymouth", "Plymouth", "dpkg:plymouth", "GPL-2.0-or-later", "freedesktop.org", None),
    ("python", "Python", "dpkg:python3", "PSF-2.0", "python.org", None),
    ("pyqt", "PyQt6", "dpkg:python3-pyqt6", "GPL-3.0", "riverbankcomputing.com", None),
]


def read(path, default=""):
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace").strip("\x00\n ")
    except OSError:
        return default


def deckos_version():
    try:
        return str(json.loads(read(VERSION_FILE, "{}")).get("version", "")).strip() or "unknown"
    except ValueError:
        return "unknown"


def dpkg_versions(packages):
    if not packages:
        return {}
    try:
        out = subprocess.run(["dpkg-query", "-W", "-f=${Package} ${Version}\n", *packages],
                             capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return {}
    result = {}
    for line in out.splitlines():
        name, _, version = line.partition(" ")
        m = re.match(r"^(?:\d+:)?(\d[\d.]*\d|\d)", version)
        if m:
            result[name] = m.group(1)
    return result


def os_name():
    info = {}
    for line in read("/etc/os-release").splitlines():
        key, _, value = line.partition("=")
        info[key] = value.strip('"')
    return info.get("PRETTY_NAME", "Linux")


def kernel():
    release = os.uname().release
    rt = " PREEMPT_RT" if "PREEMPT_RT" in os.uname().version else ""
    return release.split("-")[0] + rt


def hardware():
    model = read("/proc/device-tree/model", "Raspberry Pi")
    return re.sub(r"\s+Rev\s+[\d.]+$", "", model)


def label(obj, text, size="0me,0me", extra=""):
    return (f"<Label><ObjectName>{obj}</ObjectName><Text>{escape(text)}</Text>"
            f"<Size>{size}</Size>{extra}</Label>")


def card(comp_id, name, version, licence, site, logo):
    if logo:
        icon = f"<Label><ObjectName>DeckOSAboutLogo_{comp_id}</ObjectName><Size>40f,40f</Size></Label>"
    else:
        initials = "".join(w[0] for w in re.split(r"[\s-]+", name) if w)[:2].upper()
        icon = label("DeckOSAboutBadge", initials, "40f,40f")
    title = f"{name}  {version}" if version else name
    return f"""
          <WidgetGroup>
            <ObjectName>DeckOSAboutCard</ObjectName>
            <Layout>horizontal</Layout>
            <Size>0me,54f</Size>
            <Children>
              {icon}
              <WidgetGroup>
                <ObjectName>DeckOSAboutCardText</ObjectName>
                <Layout>vertical</Layout>
                <SizePolicy>me,me</SizePolicy>
                <Children>
                  {label("DeckOSAboutName", title, "0me,24f")}
                  {label("DeckOSAboutDetail", f"{licence}   ·   {site}", "0me,20f")}
                </Children>
              </WidgetGroup>
            </Children>
          </WidgetGroup>"""


def about_xml(version):
    pkgs = dpkg_versions([c[2][5:] for c in COMPONENTS if c[2].startswith("dpkg:")])
    osname = os_name()
    cards = []
    for comp_id, name, source, licence, site, logo in COMPONENTS:
        if source.startswith("dpkg:"):
            ver = pkgs.get(source[5:], "")
        elif source == "kernel":
            ver = kernel().split()[0]
        elif source == "os":
            m = re.search(r"(\d+)\s*\((\w+)\)", osname)
            ver = f"{m.group(1)} ({m.group(2)})" if m else ""
        else:
            ver = source
        cards.append(card(comp_id, name, ver, licence, site, logo))
    columns = [cards[i::3] for i in range(3)]
    cols_xml = "".join(f"""
        <WidgetGroup>
          <ObjectName>DeckOSAboutColumn</ObjectName>
          <Layout>vertical</Layout>
          <SizePolicy>me,min</SizePolicy>
          <Children>{''.join(col)}
          </Children>
        </WidgetGroup>""" for col in columns)

    facts = [
        ("DJ engine", f"{ENGINE_NAME}   (based on Mixxx {MIXXX_BASE})"),
        ("System", osname),
        ("Kernel", f"Linux {kernel()}"),
        ("Hardware", hardware()),
    ]
    facts_xml = "".join(f"""
              <WidgetGroup>
                <ObjectName>DeckOSAboutFact</ObjectName>
                <Layout>horizontal</Layout>
                <Size>0me,26f</Size>
                <Children>
                  {label("DeckOSAboutFactName", k, "110f,0me")}
                  {label("DeckOSAboutFactValue", v)}
                </Children>
              </WidgetGroup>""" for k, v in facts)

    legal = [
        "DeckOS is built with free and open-source software. Each component is provided under its own licence, "
        "without warranty.",
        f"DJ engine source code (GPL): {SOURCE_URL}     ·     Licence texts: /usr/share/common-licenses",
        "Mixxx is a trademark of the Mixxx project. Linux® is the registered trademark of Linus Torvalds.",
        "Debian is a registered trademark of SPI Inc. Qt is a trademark of The Qt Company. "
        "Raspberry Pi is a trademark of Raspberry Pi Ltd.",
    ]
    legal_xml = "".join(label("DeckOSAboutLegal", line, "0me,20f") for line in legal)

    return f"""<!-- Generated by ~/DeckOS/control/deckos_about.py at every Mixxx start. Do not edit. -->
<Template>
  <WidgetGroup>
    <ObjectName>DeviceHero</ObjectName>
    <Layout>horizontal</Layout>
    <Size>0me,44f</Size>
    <Children>
      <WidgetGroup>
        <ObjectName>DeviceIconBadge</ObjectName>
        <Layout>vertical</Layout>
        <Size>44f,44f</Size>
        <Children>{label("DeviceIconGlyph", "ⓘ")}</Children>
      </WidgetGroup>
      <WidgetGroup>
        <ObjectName>DeviceHeroText</ObjectName>
        <Layout>horizontal</Layout>
        <SizePolicy>me,me</SizePolicy>
        <Children>
          {label("SettingsHeader", "About DeckOS")}
          {label("DeviceHint", f"Version {version}", "0me,0me", "<Alignment>right</Alignment>")}
        </Children>
      </WidgetGroup>
    </Children>
  </WidgetGroup>

  <WidgetGroup>
    <ObjectName>DeckOSAboutHero</ObjectName>
    <Layout>horizontal</Layout>
    <Size>0me,124f</Size>
    <Children>
      <Label><ObjectName>DeckOSAboutMark</ObjectName><Size>214f,120f</Size></Label>
      <WidgetGroup>
        <ObjectName>DeckOSAboutIdentity</ObjectName>
        <Layout>vertical</Layout>
        <SizePolicy>me,me</SizePolicy>
        <Children>
          {label("DeckOSAboutTitle", "DeckOS", "0me,40f")}
          {label("DeckOSAboutVersion", f"Version {version}", "0me,26f")}
          {label("DeckOSAboutSub", "Standalone DJ system   ·   © 2026 Antoine Suatton", "0me,22f")}
        </Children>
      </WidgetGroup>
      <WidgetGroup>
        <ObjectName>DeckOSAboutFacts</ObjectName>
        <Layout>vertical</Layout>
        <Size>470f,0me</Size>
        <Children>{facts_xml}
        </Children>
      </WidgetGroup>
    </Children>
  </WidgetGroup>

  {label("DeckOSAboutBand", "OPEN SOURCE SOFTWARE", "0me,30f")}
  <WidgetGroup>
    <ObjectName>DeckOSAboutGrid</ObjectName>
    <Layout>horizontal</Layout>
    <SizePolicy>me,min</SizePolicy>
    <Children>{cols_xml}
    </Children>
  </WidgetGroup>

  {label("DeckOSAboutBand", "LEGAL", "0me,30f")}
  <WidgetGroup>
    <ObjectName>DeckOSAboutLegalBox</ObjectName>
    <Layout>vertical</Layout>
    <SizePolicy>me,me</SizePolicy>
    <Children>{legal_xml}
      <WidgetGroup><ObjectName>SettingsSpacer</ObjectName><Size>0me,0me</Size></WidgetGroup>
    </Children>
  </WidgetGroup>
</Template>
"""


NAV_FONT = "/usr/share/fonts/opentype/inter/Inter-Regular.otf"
NAV_FONT_PX = 15
NAV_PAD = 18          # space between the chevron and the row's right edge


def text_width(text):
    """Pixel width of `text` in the nav button font (Inter 15px)."""
    try:
        from PIL import ImageFont
        font = ImageFont.truetype(NAV_FONT, NAV_FONT_PX)
        return int(round(font.getlength(text)))
    except Exception:
        return int(len(text) * 8)


def nav_row(title, value, key):
    # Mixxx centres a PushButton's text, so the button is sized to its text:
    # every chevron then ends NAV_PAD pixels from the right edge of its row.
    text = f"{value}      ›"
    width = text_width(text) + 2 * NAV_PAD
    return f"""
  <WidgetGroup>
    <ObjectName>SettingsRow</ObjectName>
    <Layout>horizontal</Layout>
    <Size>0me,68f</Size>
    <Children>
      {label("SettingsRowLabel", title)}
      <PushButton>
        <ObjectName>DeckOSNavButton</ObjectName>
        <Size>{width}f,66f</Size>
        <NumberStates>1</NumberStates>
        <State><Number>0</Number><Text>{escape(text)}</Text></State>
        <LeftClickIsPushButton>true</LeftClickIsPushButton>
        <Connection>
          <ConfigKey>{key}</ConfigKey>
          <EmitOnDownPress>true</EmitOnDownPress>
        </Connection>
      </PushButton>
    </Children>
  </WidgetGroup>"""


def system_rows_xml(version):
    return ("<!-- Generated by ~/DeckOS/control/deckos_about.py at every Mixxx start. Do not edit. -->\n"
            "<Template>"
            + nav_row("Wi-Fi", "Networks and connection", "[Skin],wifi_request")
            + nav_row("Software Update", f"DeckOS {version}", "[Skin],updates_request")
            + "\n</Template>\n")


def write_if_changed(path, text):
    try:
        if path.read_text(encoding="utf-8") == text:
            return
    except OSError:
        pass
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix="." + path.name)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(tmp, 0o664)
    os.replace(tmp, path)


def main():
    if not TEMPLATES.is_dir():
        return
    version = deckos_version()
    write_if_changed(TEMPLATES / "deckos_about.xml", about_xml(version))
    write_if_changed(TEMPLATES / "deckos_system_rows.xml", system_rows_xml(version))


if __name__ == "__main__":
    main()
