#!/bin/bash

DECKOS="/home/deck/DeckOS"
CONTROL="$DECKOS/control"
ENGINE="$CONTROL/update_engine.py"
GUI="$CONTROL/maintenance_gui.py"
PENDING="$DECKOS/updates/pending"
JOURNAL="$DECKOS/backup-updates/.active-transaction.json"
LOG="$DECKOS/backup-updates/deckos-update-boot.log"

mkdir -p "$(dirname "$LOG")"

log() {
    echo "$(date '+%F %T') $1" >> "$LOG"
}

log "Contrôle de démarrage DeckOS"

# Récupération d'une transaction interrompue
if [ -f "$JOURNAL" ]; then
    log "Transaction interrompue détectée"

    if ! sudo -n /usr/bin/python3 "$ENGINE" --recover >> "$LOG" 2>&1; then
        log "ERREUR CRITIQUE : récupération impossible"
        exit 1
    fi

    log "Récupération terminée"
fi

# Recherche d'une mise à jour
if [ -f "$PENDING/manifest.json" ]; then
    log "Mise à jour détectée"

    /usr/bin/python3 "$GUI"
    RESULT=$?

    log "Interface maintenance terminée : $RESULT"

    if [ "$RESULT" -ne 0 ]; then
        log "ERREUR : interface maintenance"
        exit 1
    fi
fi

log "Contrôle terminé"
exit 0
