#!/bin/sh
CFG=/home/deck/DeckOS/config/mixxx.cfg

# Toujours démarrer Mixxx sur le skin DeckOS
if [ -f "$CFG" ]; then
    if grep -q "^ResizableSkin " "$CFG"; then
        sed -i "s/^ResizableSkin .*/ResizableSkin DeckOS/" "$CFG"
    elif grep -q "^\[Config\]" "$CFG"; then
        sed -i "/^\[Config\]/a ResizableSkin DeckOS" "$CFG"
    fi
fi

# Pages du skin avec les versions réelles (About, Software Update)
/usr/bin/python3 /home/deck/DeckOS/control/deckos_about.py >/dev/null 2>&1 || true

exec /home/deck/DeckOS/app/mixxx \
  --resource-path /home/deck/DeckOS/resources \
  --settings-path /home/deck/DeckOS/config
