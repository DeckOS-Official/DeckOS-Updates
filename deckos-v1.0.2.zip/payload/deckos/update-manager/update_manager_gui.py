#!/usr/bin/python3
"""DeckOS Update Manager — Settings > System > Update Manager.

Finds an update (official GitHub repository or USB drive), verifies it with
the DeckOS update engine and prepares it in updates/pending. The installation
itself runs at the next start (maintenance_boot.sh -> maintenance_gui.py).
"""
import hashlib
import importlib.util
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.request
from datetime import datetime
from pathlib import Path

from PyQt6.QtCore import QProcess, QThread, pyqtSignal
from PyQt6.QtWidgets import QApplication, QLabel, QProgressBar, QTextEdit

BASE = Path("/home/deck/DeckOS")
sys.path.insert(0, str(BASE / "control"))
import deckos_ui as ui  # noqa: E402

ENGINE = BASE / "control/update_engine.py"
UPDATE_DIR = BASE / "updates"
PENDING_DIR = UPDATE_DIR / "pending"
INSTALLED_VERSION = UPDATE_DIR / "installed_version.json"
USB_ROOT = Path("/media/deck")
GITHUB_BASE = "https://raw.githubusercontent.com/DeckOS-Official/DeckOS-Updates/main"

spec = importlib.util.spec_from_file_location("deckos_update_engine", ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)


def version_tuple(value):
    return tuple(int(x) for x in re.findall(r"\d+", str(value)))


def installed_version():
    try:
        return str(json.loads(INSTALLED_VERSION.read_text(encoding="utf-8"))["version"]).strip()
    except Exception:
        return "unknown"


def pending_version():
    """Version of the update waiting in updates/pending, or None.

    An empty pending folder (left behind by older DeckOS versions) is removed.
    """
    manifest = PENDING_DIR / "manifest.json"
    if manifest.is_file():
        try:
            return str(json.loads(manifest.read_text(encoding="utf-8")).get("version", "?"))
        except Exception:
            return "?"
    if PENDING_DIR.is_dir():
        try:
            PENDING_DIR.rmdir()          # only succeeds when empty
        except OSError:
            return "?"
    return None


def download(url, accept=None):
    token = os.environ.get("DECKOS_GITHUB_TOKEN", "").strip()
    headers = {"User-Agent": "DeckOS-Update-Manager"}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = "Bearer " + token
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=120) as r:
        return r.read()


def release_base():
    """Raw URL of the latest commit of the update repository.

    raw.githubusercontent.com caches each file for 5 minutes independently, so
    right after a release the manifest and its signature could come from two
    different versions. Files read from one commit id are always consistent.
    """
    try:
        sha = download("https://api.github.com/repos/DeckOS-Official/DeckOS-Updates/commits/main",
                       accept="application/vnd.github.sha").decode().strip()
        if len(sha) == 40 and all(c in "0123456789abcdef" for c in sha):
            return GITHUB_BASE.rsplit("/", 1)[0] + "/" + sha
    except Exception:
        pass
    return GITHUB_BASE


# ----------------------------------------------------------------------------
# Workers
# ----------------------------------------------------------------------------
class UsbWorker(QThread):
    completed = pyqtSignal(bool, str, object)

    def run(self):
        valid, errors = [], []
        try:
            if not USB_ROOT.is_dir() or not any(USB_ROOT.iterdir()):
                self.completed.emit(False, "No USB drive detected. Plug in a drive and try again.", None)
                return
            for current, dirs, files in os.walk(USB_ROOT, followlinks=False):
                path = Path(current)
                depth = len(path.relative_to(USB_ROOT).parts)
                dirs[:] = [d for d in dirs if not d.startswith(".")
                           and d not in ("System Volume Information", "$RECYCLE.BIN")
                           and not (path / d).is_symlink()]
                if depth >= 6:
                    dirs[:] = []
                if "manifest.json" not in files:
                    continue
                try:
                    manifest, package = engine.locate_package(path)
                    engine.inspect_archive(package)
                    valid.append({"folder": path, "manifest": manifest, "package": package, "source": "USB drive"})
                except Exception as exc:
                    errors.append(f"{path}: {exc}")
            if valid:
                self.completed.emit(True, f"{len(valid)} valid package(s) found.", valid)
            else:
                self.completed.emit(False, errors[0] if errors else "No manifest.json found on the USB drive.", None)
        except Exception as exc:
            self.completed.emit(False, str(exc), None)


class GitHubWorker(QThread):
    completed = pyqtSignal(bool, str, object)

    def __init__(self, mode, manifest=None):
        super().__init__()
        self.mode = mode
        self.manifest = manifest

    def run(self):
        try:
            if self.mode == "check":
                base = release_base()
                raw = download(base + "/manifest.json")
                signature = download(base + "/manifest.json.sig")
                with tempfile.TemporaryDirectory() as tmp:
                    sig_path = Path(tmp) / "manifest.json.sig"
                    sig_path.write_bytes(signature)
                    engine.verify_signature(raw, sig_path)
                manifest = json.loads(raw.decode("utf-8"))
                manifest["_raw"] = raw.decode("utf-8")
                manifest["_sig"] = signature.hex()
                manifest["_base"] = base
                version = str(manifest.get("version", "")).strip()
                package = str(manifest.get("package", "")).strip()
                digest = str(manifest.get("sha256", "")).lower()
                if not version:
                    raise RuntimeError("The remote manifest has no version.")
                if (not package.endswith(".zip") or "/" in package or "\\" in package
                        or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest)):
                    raise RuntimeError("The remote manifest is invalid.")
                self.completed.emit(True, f"Latest version online: {version}", manifest)
                return

            manifest = self.manifest
            data = download(manifest.get("_base", GITHUB_BASE) + "/" + manifest["package"])
            if hashlib.sha256(data).hexdigest() != manifest["sha256"].lower():
                raise RuntimeError("SHA-256 check failed: the download is corrupted.")
            UPDATE_DIR.mkdir(parents=True, exist_ok=True)
            staging = Path(tempfile.mkdtemp(prefix=".github-staging-", dir=UPDATE_DIR))
            # keep the manifest byte for byte: it is what the signature covers
            (staging / manifest["package"]).write_bytes(data)
            (staging / "manifest.json").write_text(manifest["_raw"], encoding="utf-8")
            (staging / "manifest.json.sig").write_bytes(bytes.fromhex(manifest["_sig"]))
            checked_manifest, checked_package = engine.locate_package(staging)
            engine.inspect_archive(checked_package)
            self.completed.emit(True, "Download verified.",
                                {"folder": staging, "manifest": checked_manifest,
                                 "package": checked_package, "source": "Official repository"})
        except Exception as exc:
            self.completed.emit(False, str(exc), None)


# ----------------------------------------------------------------------------
# Window
# ----------------------------------------------------------------------------
class UpdateManager(ui.DeckOSWindow):

    def __init__(self):
        super().__init__("Update Manager", "Search, verify and prepare DeckOS updates")
        self.busy = False
        self.package_data = None
        self.remote_manifest = None
        self.worker = None

        self.content.addWidget(ui.Band("Installed"))
        self.version_row = ui.Row("DeckOS version")
        self.version_value = self.version_row.add(QLabel(installed_version()))
        self.version_value.setObjectName("RowValue")
        self.content.addWidget(self.version_row)
        self.content.addSpacing(ui.ROW_GAP)

        self.content.addWidget(ui.Band("Online update", "Official DeckOS repository"))
        self.online_row = ui.Row("Check for updates", "Not checked yet")
        self.online_button = self.online_row.add(ui.action_button("CHECK", "Action", self.github_check))
        self.online_button.setFixedWidth(170)
        self.content.addWidget(self.online_row)
        self.content.addSpacing(ui.ROW_GAP)

        self.content.addWidget(ui.Band("USB update"))
        self.usb_row = ui.Row("USB drive", "A folder with manifest.json and its ZIP package")
        self.usb_button = self.usb_row.add(ui.action_button("SCAN USB", "Action", self.usb_scan))
        self.usb_button.setFixedWidth(170)
        self.content.addWidget(self.usb_row)
        self.content.addSpacing(ui.ROW_GAP)

        self.content.addWidget(ui.Band("Update package"))
        self.package_row = ui.Row("No package selected", "Check online or scan a USB drive")
        self.cancel_button = self.package_row.add(ui.action_button("CANCEL UPDATE", "Danger", self.cancel_pending))
        self.prepare_button = self.package_row.add(ui.action_button("PREPARE UPDATE", "Primary", self.prepare_update))
        self.restart_button = self.package_row.add(ui.action_button("RESTART NOW", "Primary", self.restart))
        for b in (self.cancel_button, self.prepare_button, self.restart_button):
            b.setFixedWidth(170)
        self.content.addWidget(self.package_row)
        self.content.addSpacing(ui.ROW_GAP)

        self.progress_row = ui.Row("Ready")
        self.progress = self.progress_row.add(QProgressBar())
        self.progress.setRange(0, 100)
        self.progress.setTextVisible(False)
        self.progress.setFixedWidth(360)
        self.percent = self.progress_row.add(QLabel("0 %"))
        self.percent.setObjectName("RowSub")
        self.percent.setFixedWidth(44)
        self.content.addWidget(self.progress_row)
        self.content.addSpacing(ui.ROW_GAP)

        self.content.addWidget(ui.Band("Log"))
        self.log_view = QTextEdit()
        self.log_view.setObjectName("Log")
        self.log_view.setReadOnly(True)
        self.content.addWidget(self.log_view, 1)

        self.refresh_package_row()

    # -- helpers ----------------------------------------------------------
    def can_leave(self):
        return not self.busy

    def log(self, text):
        self.log_view.append(f"{datetime.now():%H:%M:%S}  {text}")

    def set_progress(self, value, text=None, state=""):
        self.progress.setValue(value)
        self.percent.setText(f"{value} %")
        if text is not None:
            self.progress_row.label.setText(text)
        ui.restyle(self.progress_row.label, state=state)

    def set_busy(self, busy):
        self.busy = busy
        self.online_button.setEnabled(not busy)
        self.usb_button.setEnabled(not busy)
        self.refresh_package_row()

    def refresh_package_row(self):
        pending = pending_version()
        self.cancel_button.setVisible(pending is not None)
        self.restart_button.setVisible(pending is not None)
        self.prepare_button.setVisible(pending is None)
        if pending is not None:
            self.package_row.label.setText(f"DeckOS {pending} is ready to install")
            self.package_row.set_sub("It will be installed when DeckOS restarts", "ok")
            self.cancel_button.setEnabled(not self.busy)
            self.restart_button.setEnabled(not self.busy)
            return
        if self.package_data:
            m = self.package_data["manifest"]
            self.package_row.label.setText(f"DeckOS {m.get('version', '?')}")
            self.package_row.set_sub(
                f"{self.package_data['package'].name}   ·   SHA-256 verified   ·   "
                f"{self.package_data['source']}", "ok")
        else:
            self.package_row.label.setText("No package selected")
            self.package_row.set_sub("Check online or scan a USB drive")
        self.prepare_button.setEnabled(bool(self.package_data) and not self.busy)

    # -- online -----------------------------------------------------------
    def github_check(self):
        if self.busy:
            return
        self.package_data = None
        self.remote_manifest = None
        self.set_busy(True)
        self.online_row.set_sub("Connecting to the official repository…", "busy")
        self.set_progress(10, "Checking online…")
        self.log("Checking the official repository…")
        self.worker = GitHubWorker("check")
        self.worker.completed.connect(self.github_checked)
        self.worker.start()

    def github_checked(self, ok, message, manifest):
        self.set_busy(False)
        self.log(message)
        if not ok:
            self.online_row.set_sub("Connection failed — check the Wi-Fi", "error")
            self.set_progress(0, "Online check failed", "error")
            return
        remote = str(manifest["version"])
        current = installed_version()
        self.remote_manifest = manifest
        newer = current == "unknown" or version_tuple(remote) > version_tuple(current)
        self.set_progress(100 if not newer else 30, "Online check done")
        self._rebind(self.online_button, "DOWNLOAD" if newer else "CHECK AGAIN",
                     self.github_download if newer else self.github_check)
        if newer:
            self.online_row.set_sub(f"Version {remote} is available", "ok")
        else:
            self.online_row.set_sub(f"DeckOS is up to date ({current})", "ok")

    def github_download(self):
        if self.busy or not self.remote_manifest:
            return
        self.set_busy(True)
        self.online_row.set_sub(f"Downloading version {self.remote_manifest['version']}…", "busy")
        self.set_progress(50, "Downloading…")
        self.log("Downloading the package…")
        self.worker = GitHubWorker("download", self.remote_manifest)
        self.worker.completed.connect(self.github_downloaded)
        self.worker.start()

    def github_downloaded(self, ok, message, data):
        self.log(message)
        self._rebind(self.online_button, "CHECK AGAIN", self.github_check)
        if not ok:
            self.set_busy(False)
            self.online_row.set_sub("Download failed", "error")
            self.set_progress(0, "Download failed", "error")
            return
        self.online_row.set_sub(f"Version {data['manifest'].get('version')} downloaded and verified", "ok")
        self.package_data = data
        self.set_busy(False)
        self.set_progress(100, "Package verified — ready to prepare", "ok")
        self.log("SHA-256 and archive checks passed. Nothing has been installed yet.")

    # -- USB --------------------------------------------------------------
    def usb_scan(self):
        if self.busy:
            return
        self.package_data = None
        self.set_busy(True)
        self.usb_row.set_sub("Searching the USB drives…", "busy")
        self.set_progress(20, "Scanning USB drives…")
        self.log(f"Scanning {USB_ROOT} …")
        self.worker = UsbWorker()
        self.worker.completed.connect(self.usb_done)
        self.worker.start()

    def usb_done(self, ok, message, packages):
        self.set_busy(False)
        self.log(message)
        if not ok:
            self.usb_row.set_sub(message, "error")
            self.set_progress(0, "No valid package found", "error")
            return
        selected = packages[0]
        if len(packages) > 1:
            choices = [(f"DeckOS {p['manifest'].get('version', '?')}   —   {p['folder']}", p) for p in packages]
            selected = ui.choose(self, "Several packages found", "Which package do you want to use?", choices)
            if selected is None:
                self.usb_row.set_sub("Selection cancelled")
                return
        self.package_data = selected
        self.usb_row.set_sub(f"Found DeckOS {selected['manifest'].get('version', '?')} on the USB drive", "ok")
        self.set_progress(100, "Package verified — ready to prepare", "ok")
        self.refresh_package_row()

    # -- prepare / cancel / restart ---------------------------------------
    def prepare_update(self):
        if not self.package_data or self.busy:
            return
        version = self.package_data["manifest"].get("version", "?")
        if not ui.ask(self, "Prepare update",
                      f"Prepare DeckOS {version}?\n\nThe update is installed at the next restart. "
                      "Nothing is changed before that.",
                      [("CANCEL", "Action", False), ("PREPARE", "Primary", True)]):
            return
        if pending_version() is not None:
            ui.inform(self, "Update Manager", "An update is already prepared.", "Action")
            return
        source = self.package_data["folder"]
        package = self.package_data["package"]
        UPDATE_DIR.mkdir(parents=True, exist_ok=True)
        temp = Path(tempfile.mkdtemp(prefix=".pending-staging-", dir=UPDATE_DIR))
        try:
            target = temp / package.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(package, target)
            shutil.copy2(source / "manifest.json", temp / "manifest.json")
            shutil.copy2(source / "manifest.json.sig", temp / "manifest.json.sig")
            _, checked = engine.locate_package(temp)
            engine.inspect_archive(checked)
            if PENDING_DIR.exists():
                raise RuntimeError("An update was prepared in the meantime.")
            os.rename(temp, PENDING_DIR)
            if source.parent == UPDATE_DIR and source.name.startswith(".github-staging-"):
                shutil.rmtree(source, ignore_errors=True)
            self.package_data = None
            self.set_progress(100, f"DeckOS {version} prepared — restart to install", "ok")
            self.log(f"DeckOS {version} prepared in {PENDING_DIR}. Restart to install it.")
        except Exception as exc:
            shutil.rmtree(temp, ignore_errors=True)
            self.set_progress(0, "Preparation failed", "error")
            self.log("ERROR: " + str(exc))
            ui.inform(self, "Preparation failed", str(exc), "Action")
        self.refresh_package_row()

    def cancel_pending(self):
        if self.busy:
            return
        if ui.ask(self, "Cancel update",
                  "Remove the prepared update?\n\nDeckOS stays on its current version.",
                  [("KEEP IT", "Action", False), ("REMOVE", "Danger", True)]):
            shutil.rmtree(PENDING_DIR, ignore_errors=True)
            self.log("Prepared update removed.")
            self.set_progress(0, "Ready")
            self.refresh_package_row()

    def restart(self):
        if ui.ask(self, "Restart DeckOS",
                  "Restart now to install the update?\n\nPlayback stops during the restart.",
                  [("LATER", "Action", False), ("RESTART", "Primary", True)]):
            self.log("Restarting…")
            QProcess.startDetached("systemctl", ["reboot"])

    @staticmethod
    def _rebind(button, text, slot):
        button.setText(text)
        try:
            button.clicked.disconnect()
        except TypeError:
            pass
        button.clicked.connect(slot)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("DeckOS Update Manager")
    ui.setup_app(app)
    window = UpdateManager()
    window.present()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
