# DeckOS — paramètres tactiles et dossier d'icônes

Contenu :
- `settings.xml` : page de paramètres avec sélecteur de contrôleurs tactile.
- `style.qss` : habillage graphique sombre/orange et zones de sélection agrandies.
- `icons/devices/` : dossier dans lequel déposer tes icônes de contrôleurs, avec modèle SVG et convention de nommage.

## Installation
Remplace les fichiers `settings.xml` et `style.qss` dans le dossier du skin DeckOS, en gardant une copie de sauvegarde des fichiers d'origine. Le dossier `icons/devices/` peut être copié à côté des autres ressources du skin.

## Limite connue
Le dossier d'icônes est préparé, mais l'affichage automatique d'une icône différente par périphérique nécessite une modification du composant Mixxx `ControllerList` qui génère les lignes. Ce package n'inclut pas le code source de Mixxx et ne prétend pas activer cette association dynamique à lui seul.

## Harmonisation Browse / Sampler / Levels
- `style.qss` : nouvelle section finale alignée sur PLAY (fond `#0b0f15`, cartes `#111721`, bords `#2a3444`, rayon 8px, orange deck 1 / vert deck 2).
- `library.xml`, `samplers.xml`, `levels.xml` : bandeau de decks renommé `DecksCompact`, `LibraryBody` / `PageSectionHeader` ajoutés pour le style.
- `icons/knob.svg` : potard repeint dans la palette PLAY.

## Levels — barres tactiles, style RX3 (novembre 2026)
- Page Levels en deux panneaux dessinés comme le panneau BEAT FX : **OUTPUT** (Master, Booth, Phones, courbe EQ | ISO, RESET 0 dB) et **MASTER EQ** (8 bandes, FLAT).
- Chaque ligne : `LIBELLÉ [ − ] [ barre ] [ + ] valeur`, boutons 52 × 44 px, barre aussi déplaçable au doigt, repère 0 dB au centre. Barres bleues pour les sorties, grises pour l'EQ (comme MIX / DEPTH du Beat FX).
- Fichiers : `levels.xml`, `templates/level_bar.xml`, `templates/eq_bar.xml`, `icons/level_bar_bg.png`, `icons/level_bar_fg_blue.png`, `icons/level_bar_fg_gray.png`, `icons/level_bar_handle.svg`.
- Pas des boutons : 1/10 de la course par appui (≈ 2,8 dB en sortie, 2,4 dB sur l'EQ). Pour un réglage fin : `<SetVariable name="Step">_small</SetVariable>` dans `levels.xml`.

## Thème RX3 sur toutes les pages (novembre 2026)
- Couleurs relevées au pixel sur le rendu officiel de l'écran XDJ-RX3 (page produit Pioneer DJ) et sur une photo de l'écran BROWSE.
- `style.qss` : section finale « THÈME RX3 — toutes les pages ». Chaque règle commence par `#Mixxx` pour primer sur les anciennes sections ; la supprimer rend l'ancien rendu.
  - PLAY : onglets en touches noires (libellé bleu, page active en blanc), cases DECK gris moyen à en-tête gris et filet bleu, valeurs orange, panneau BEAT FX (bandeau gris, effet bleu plein, STATUS | BEAT FX segmenté), hot cues en cases grises, bandeaux de decks noirs (filet bleu / cadre gris clair sur le deck sélectionné), chiffres fins, pastille tempo verte, cadre BPM blanc puis orange en MASTER, QUANTIZE rouge-orange.
  - BROWSE : lignes alternées gris foncé, ligne sélectionnée bleu très clair, en-têtes de colonnes gris, colonne de gauche sombre avec élément courant orange.
  - SAMPLER, LEVELS, SETTINGS et leurs sous-pages : mêmes panneaux, bandeaux-titres, boutons segmentés, boutons à contour bleu et lignes de menu.
- `waveform.xml` : fond noir, 3 bandes bleu #1a5ad8 / ambre #eea536 / crème #f7e9cc, grille grise et temps forts rouges, boucle orange.
- `deck.xml` : vue d'ensemble bleue du RX3, partie déjà jouée assombrie.
- `effects.xml` : panneau BEAT FX élargi (300 px max).

## BROWSE façon RX3 (novembre 2026)
- `library.xml` : bandeau gris « MENU + chemin » plus fin (44 px), colonne de catégories resserrée (190 px), fond de liste gris.
- `style.qss` (section BROWSE du thème RX3) : en-têtes de colonnes gris foncé en majuscules, lignes gris alternées en police 18 px, ligne sélectionnée bleue texte blanc, catégories en tuiles de 44 px (sélection bleue), ascenseurs gris fins.
- `templates/deck_mini.xml` (nouveau) : mini bandeau de deck du RX3 en bas de BROWSE, SAMPLER et LEVELS : DECK n (orange en lecture) + REMAIN/TIME et temps, vue d'ensemble, cadre BPM blanc ou orange avec MASTER.
- Pas de boutons LOAD 1 / LOAD 2 (le chargement se fait par les boutons physiques).

## Settings, MASTER et format 1280 × 800 (novembre 2026)
- **MASTER** : `sync_leader` vaut 1 (maître automatique) ou 2 (maître choisi) ; l'ancien style ne reconnaissait que 1. Il est maintenant ramené à 0/1 dans une propriété `master` : cadre BPM, chiffres BPM et étiquette MASTER passent en orange et y restent, sur PLAY comme sur les mini bandeaux.
- **Settings** (`settings.xml`, `templates/library_column_row.xml`, `templates/setting_subtab_button.xml`) :
  - colonne de catégories à gauche en tuiles de 52 px, comme BROWSE ;
  - en-tête de page en bandeau gris (icône + titre + aide à droite) ;
  - General regroupé en trois cartes : DECK (Jog, Vinyl Brake, Hot Cue, Load Gate, Xfader 1, Xfader 2), WAVEFORM AND DISPLAY (Wave, Apply Waveform EQ, Key), LIBRARY (Clear, Played) ;
  - Xfader : choix segmentés A | THRU | B par deck au lieu de boutons à faire défiler ;
  - colonnes de la bibliothèque : choix segmentés OFF | XS | S | M | L au lieu d'un bouton à faire défiler ;
  - fonds explicites partout (fini les fonds bleutés des anciennes sections) ;
  - mini bandeau de decks RX3 en bas.
- **1280 × 800** : `skin.xml` MinimumSize 1280,800 ; bandeaux de decks de PLAY 190 px ; cases DECK 160 px ; panneau BEAT FX 210 px.
