# DeckOS — paramètres tactiles et dossier d'icônes

Contenu :
- `settings.xml` : page de paramètres avec sélecteur de contrôleurs tactile.
- `style.qss` : habillage graphique sombre/orange et zones de sélection agrandies.
- `icons/devices/` : dossier dans lequel déposer tes icônes de contrôleurs, avec modèle SVG et convention de nommage.

## Installation
Remplace les fichiers `settings.xml` et `style.qss` dans le dossier du skin DeckOS, en gardant une copie de sauvegarde des fichiers d'origine. Le dossier `icons/devices/` peut être copié à côté des autres ressources du skin.

## Limite connue
Le dossier d'icônes est préparé, mais l'affichage automatique d'une icône différente par périphérique nécessite une modification du composant Mixxx `ControllerList` qui génère les lignes. Ce package n'inclut pas le code source de Mixxx et ne prétend pas activer cette association dynamique à lui seul.

## Harmonisation Browse / Sampler / Levels
- `style.qss` : nouvelle section finale alignée sur PLAY (fond `#0b0f15`, cartes `#111721`, bords `#2a3444`, rayon 8px, orange deck 1 / vert deck 2).
- `library.xml`, `samplers.xml`, `levels.xml` : bandeau de decks renommé `DecksCompact`, `LibraryBody` / `PageSectionHeader` ajoutés pour le style.
- `icons/knob.svg` : potard repeint dans la palette PLAY.
