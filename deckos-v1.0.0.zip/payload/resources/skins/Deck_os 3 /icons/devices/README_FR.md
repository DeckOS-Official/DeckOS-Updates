# Icônes des périphériques — DeckOS

Dépose ici tes icônes personnalisées pour les contrôleurs MIDI/USB affichés dans **Paramètres > Device / Contrôleurs**.

## Format conseillé
- SVG de préférence (vectoriel, net à toute taille), ou PNG transparent.
- Canevas carré : 256 × 256 px pour PNG.
- Sujet centré, marges régulières, fond transparent.
- Évite d'inclure le nom du périphérique dans l'image : le nom sera affiché à côté.
- Utilise des noms de fichiers simples, en minuscules, sans accents ni espaces.

## Convention de nommage
Nomme chaque fichier à partir du nom du périphérique, par exemple :

- `pioneer_ddj_flx4.svg`
- `pioneer_ddj_1000.svg`
- `roland_tr8s.svg`
- `generic_midi_controller.svg`

Pour chaque contrôleur, garde idéalement un seul fichier et une seule extension.

## Important — intégration
Ce dossier est préparé pour accueillir les icônes. La liste des contrôleurs est générée dynamiquement par le composant `ControllerList` de Mixxx. Le XML/QSS d'un skin ne sait pas, à lui seul, associer automatiquement chaque nom de périphérique détecté à un fichier différent.

Les fichiers que tu déposeras ici ne s'afficheront donc pas automatiquement dans les lignes de sélection avec la version actuelle. Il faudra ajouter le chargement d'icône dans le composant qui crée les lignes `ControllerRow`, en utilisant cette convention de nommage. La structure du dossier et les noms proposés sont prévus pour cette étape, sans modifier les réglages ni les liaisons existantes.
